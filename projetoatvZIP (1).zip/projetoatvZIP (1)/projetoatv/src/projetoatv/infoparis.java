package projetoatv;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTabbedPane;
import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JTextPane;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Font;
import javax.swing.JSeparator;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Toolkit;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.net.URI;
import java.awt.event.ActionEvent;

public class infoparis {

	private JFrame frmPacoteParis;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					infoparis window = new infoparis();
					window.frmPacoteParis.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public infoparis() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmPacoteParis = new JFrame();
		frmPacoteParis.setIconImage(Toolkit.getDefaultToolkit().getImage(infoparis.class.getResource("/imagens/franca.png")));
		frmPacoteParis.setTitle("PACOTE PARIS");
		frmPacoteParis.setBounds(100, 100, 1154, 853);
		frmPacoteParis.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmPacoteParis.getContentPane().setLayout(new BorderLayout(0, 0));
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		frmPacoteParis.getContentPane().add(tabbedPane);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		tabbedPane.addTab("SERVIÇOS INCLUSOS", null, panel, null);
		panel.setLayout(null);
		
		JTextPane txtpnParis = new JTextPane();
		txtpnParis.setText("Paris - 2025 \r\n\r\n\r\n");
		txtpnParis.setForeground(Color.BLACK);
		txtpnParis.setFont(new Font("Tahoma", Font.BOLD, 20));
		txtpnParis.setBackground(Color.WHITE);
		txtpnParis.setBounds(641, 11, 152, 31);
		panel.add(txtpnParis);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(526, 62, 358, 2);
		panel.add(separator);
		
		JTextPane txtpnPartidasDe_1 = new JTextPane();
		txtpnPartidasDe_1.setText("Partidas de 15 de Abril 2025 a 21 de Abril 2025\r\n\r\n\r\n");
		txtpnPartidasDe_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		txtpnPartidasDe_1.setBackground(new Color(53, 189, 255));
		txtpnPartidasDe_1.setBounds(560, 79, 310, 26);
		panel.add(txtpnPartidasDe_1);
		
		JLabel lblNewLabel_2 = new JLabel("Passagem Aéria Econômica");
		lblNewLabel_2.setIcon(new ImageIcon(infoparis.class.getResource("/imagens/aviao (1).png")));
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2.setBackground(Color.WHITE);
		lblNewLabel_2.setBounds(31, 194, 240, 27);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1_1 = new JLabel("Passagens aéreas de ida e volta em classe econômica.");
		lblNewLabel_2_1_1.setForeground(Color.GRAY);
		lblNewLabel_2_1_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_2_1_1.setBounds(31, 219, 319, 27);
		panel.add(lblNewLabel_2_1_1);
		
		JLabel lblNewLabel_2_2 = new JLabel("Guia Acompanhante ");
		lblNewLabel_2_2.setIcon(new ImageIcon(infoparis.class.getResource("/imagens/guia-turistico (1).png")));
		lblNewLabel_2_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2_2.setBackground(Color.WHITE);
		lblNewLabel_2_2.setBounds(31, 257, 263, 27);
		panel.add(lblNewLabel_2_2);
		
		JLabel lblNewLabel_2_1_1_2 = new JLabel("Durante todo o trajeto.");
		lblNewLabel_2_1_1_2.setForeground(Color.GRAY);
		lblNewLabel_2_1_1_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_2_1_1_2.setBounds(31, 291, 237, 27);
		panel.add(lblNewLabel_2_1_1_2);
		
		JLabel lblNewLabel_2_1_1_1 = new JLabel("Com quarto duplo ou triplo.");
		lblNewLabel_2_1_1_1.setForeground(Color.GRAY);
		lblNewLabel_2_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_2_1_1_1.setBounds(384, 227, 319, 27);
		panel.add(lblNewLabel_2_1_1_1);
		
		JLabel lblNewLabel_2_1 = new JLabel("Hospedagem + Café da Manhã");
		lblNewLabel_2_1.setIcon(new ImageIcon(infoparis.class.getResource("/imagens/cama.png")));
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2_1.setBackground(Color.WHITE);
		lblNewLabel_2_1.setBounds(384, 194, 240, 27);
		panel.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_2_2_1 = new JLabel("Transfer Local");
		lblNewLabel_2_2_1.setIcon(new ImageIcon(infoparis.class.getResource("/imagens/carros.png")));
		lblNewLabel_2_2_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2_2_1.setBackground(Color.WHITE);
		lblNewLabel_2_2_1.setBounds(384, 264, 263, 27);
		panel.add(lblNewLabel_2_2_1);
		
		JTextPane txtpnProgramaDe = new JTextPane();
		txtpnProgramaDe.setText("5 noites de hospedagem com café da manhã.");
		txtpnProgramaDe.setFont(new Font("Tahoma", Font.BOLD, 12));
		txtpnProgramaDe.setBounds(31, 358, 426, 31);
		panel.add(txtpnProgramaDe);
		
		JTextPane txtpnAcompanhamentoDeGuia = new JTextPane();
		txtpnAcompanhamentoDeGuia.setText("· Acompanhamento de guia em espanhol (com conhecimento em português).");
		txtpnAcompanhamentoDeGuia.setFont(new Font("Tahoma", Font.PLAIN, 12));
		txtpnAcompanhamentoDeGuia.setBounds(31, 400, 467, 31);
		panel.add(txtpnAcompanhamentoDeGuia);
		
		JTextPane txtpnIngressosPasseios = new JTextPane();
		txtpnIngressosPasseios.setText("· Ingressos Passeios\r\n");
		txtpnIngressosPasseios.setFont(new Font("Tahoma", Font.BOLD, 12));
		txtpnIngressosPasseios.setBounds(31, 442, 426, 31);
		panel.add(txtpnIngressosPasseios);
		
		JLabel lblNewLabel_2_1_1_2_1 = new JLabel("Inclui descolamento entre cidades.");
		lblNewLabel_2_1_1_2_1.setForeground(Color.GRAY);
		lblNewLabel_2_1_1_2_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_2_1_1_2_1.setBounds(384, 291, 237, 27);
		panel.add(lblNewLabel_2_1_1_2_1);
		
		JButton btnExploreParis = new JButton("EXPLORE PARIS");
		btnExploreParis.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String url = "https://www.google.com/maps/place/Paris,+Fran%C3%A7a/data=!4m2!3m1!1s0x47e66e1f06e2b70f:0x40b82c3688c9460?sa=X&ved=1t:242&ictx=111";
					if (Desktop.isDesktopSupported()) {
						Desktop desktop = Desktop.getDesktop();
						desktop.browse(new URI(url));
					} else {
						System.out.println("Desktop não suportado.");
					}
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		});
		btnExploreParis.setBounds(193, 497, 199, 23);
		panel.add(btnExploreParis);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(infoparis.class.getResource("/imagens/360_F_284387777_pyzUzBgK1mmEPmdTyqLZh9z7GjnosVEX (1).jpg")));
		lblNewLabel_1.setBounds(611, 176, 300, 202);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("");
		lblNewLabel_1_1.setIcon(new ImageIcon(infoparis.class.getResource("/imagens/98 (1).jpg")));
		lblNewLabel_1_1.setBounds(611, 399, 300, 202);
		panel.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(infoparis.class.getResource("/imagens/tower-103417_640 (1).jpg")));
		lblNewLabel.setBounds(921, 190, 300, 390);
		panel.add(lblNewLabel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(255, 255, 255));
		tabbedPane.addTab("SERVIÇOS NÃO INCLUSOS", null, panel_1, null);
		panel_1.setLayout(null);
		
		JTextPane txtpnParis_1 = new JTextPane();
		txtpnParis_1.setText("Paris - 2025 \r\n\r\n\r\n");
		txtpnParis_1.setForeground(Color.BLACK);
		txtpnParis_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		txtpnParis_1.setBackground(Color.WHITE);
		txtpnParis_1.setBounds(545, 11, 152, 31);
		panel_1.add(txtpnParis_1);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(430, 62, 358, 2);
		panel_1.add(separator_1);
		
		JTextPane txtpnPartidasDe_1_1 = new JTextPane();
		txtpnPartidasDe_1_1.setText("Partidas de 15 de Abril 2025 a 21 de Abril 2025\r\n\r\n\r\n");
		txtpnPartidasDe_1_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		txtpnPartidasDe_1_1.setBackground(new Color(53, 189, 255));
		txtpnPartidasDe_1_1.setBounds(464, 79, 310, 26);
		panel_1.add(txtpnPartidasDe_1_1);
		
		JLabel lblNewLabel_3_3 = new JLabel("Refeições não mencionadas.");
		lblNewLabel_3_3.setIcon(new ImageIcon(infoparis.class.getResource("/imagens/numero-1.png")));
		lblNewLabel_3_3.setToolTipText("DATA:");
		lblNewLabel_3_3.setForeground(Color.GRAY);
		lblNewLabel_3_3.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_3_3.setBounds(10, 163, 271, 16);
		panel_1.add(lblNewLabel_3_3);
		
		JLabel lblNewLabel_3_3_1 = new JLabel("Seguro assistência saúde/bagagem.");
		lblNewLabel_3_3_1.setIcon(new ImageIcon(infoparis.class.getResource("/imagens/numero-2 (1).png")));
		lblNewLabel_3_3_1.setToolTipText("DATA:");
		lblNewLabel_3_3_1.setForeground(Color.GRAY);
		lblNewLabel_3_3_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_3_3_1.setBounds(10, 197, 271, 16);
		panel_1.add(lblNewLabel_3_3_1);
		
		JLabel lblNewLabel_3_3_1_1 = new JLabel("Extras de caráter pessoal\r\n");
		lblNewLabel_3_3_1_1.setIcon(new ImageIcon(infoparis.class.getResource("/imagens/numero-3.png")));
		lblNewLabel_3_3_1_1.setToolTipText("DATA:");
		lblNewLabel_3_3_1_1.setForeground(Color.GRAY);
		lblNewLabel_3_3_1_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_3_3_1_1.setBounds(10, 231, 271, 16);
		panel_1.add(lblNewLabel_3_3_1_1);
		
		JLabel lblNewLabel_3_3_1_1_2 = new JLabel("(telefonemas, bebidas, lavanderia).");
		lblNewLabel_3_3_1_1_2.setToolTipText("DATA:");
		lblNewLabel_3_3_1_1_2.setForeground(Color.GRAY);
		lblNewLabel_3_3_1_1_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_3_3_1_1_2.setBounds(18, 258, 271, 16);
		panel_1.add(lblNewLabel_3_3_1_1_2);
		
		JLabel lblNewLabel_3_3_1_1_1 = new JLabel("Taxas aeroportuárias nacionais e internacionais.");
		lblNewLabel_3_3_1_1_1.setIcon(new ImageIcon(infoparis.class.getResource("/imagens/numero-4 (1).png")));
		lblNewLabel_3_3_1_1_1.setToolTipText("DATA:");
		lblNewLabel_3_3_1_1_1.setForeground(Color.GRAY);
		lblNewLabel_3_3_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_3_3_1_1_1.setBounds(299, 163, 323, 16);
		panel_1.add(lblNewLabel_3_3_1_1_1);
		
		JLabel lblNewLabel_3_3_1_1_1_3 = new JLabel("Excesso de bagagem.");
		lblNewLabel_3_3_1_1_1_3.setIcon(new ImageIcon(infoparis.class.getResource("/imagens/numero-5.png")));
		lblNewLabel_3_3_1_1_1_3.setToolTipText("DATA:");
		lblNewLabel_3_3_1_1_1_3.setForeground(Color.GRAY);
		lblNewLabel_3_3_1_1_1_3.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_3_3_1_1_1_3.setBounds(299, 197, 271, 16);
		panel_1.add(lblNewLabel_3_3_1_1_1_3);
		
		JLabel lblNewLabel_3_3_1_1_1_1 = new JLabel("Qualquer item não mencionado como incluído.");
		lblNewLabel_3_3_1_1_1_1.setIcon(new ImageIcon(infoparis.class.getResource("/imagens/numero-6.png")));
		lblNewLabel_3_3_1_1_1_1.setToolTipText("DATA:");
		lblNewLabel_3_3_1_1_1_1.setForeground(Color.GRAY);
		lblNewLabel_3_3_1_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_3_3_1_1_1_1.setBounds(299, 231, 310, 16);
		panel_1.add(lblNewLabel_3_3_1_1_1_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(255, 255, 255));
		tabbedPane.addTab("ROTEIRO", null, panel_2, null);
		panel_2.setLayout(null);
		
		JTextPane txtpnParis_2 = new JTextPane();
		txtpnParis_2.setText("Paris - 2025 \r\n\r\n\r\n");
		txtpnParis_2.setForeground(Color.BLACK);
		txtpnParis_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		txtpnParis_2.setBackground(Color.WHITE);
		txtpnParis_2.setBounds(545, 11, 152, 31);
		panel_2.add(txtpnParis_2);
		
		JTextPane txtpnPartidasDe_1_2 = new JTextPane();
		txtpnPartidasDe_1_2.setText("Partidas de 15 de Abril 2025 a 21 de Abril 2025\r\n\r\n\r\n");
		txtpnPartidasDe_1_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		txtpnPartidasDe_1_2.setBackground(new Color(53, 189, 255));
		txtpnPartidasDe_1_2.setBounds(464, 79, 310, 26);
		panel_2.add(txtpnPartidasDe_1_2);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setBounds(430, 62, 358, 2);
		panel_2.add(separator_2);
		
		JLabel lblNewLabel_3 = new JLabel("Paris");
		lblNewLabel_3.setIcon(new ImageIcon(infoparis.class.getResource("/imagens/numero-1.png")));
		lblNewLabel_3.setToolTipText("DATA:");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3.setBounds(10, 147, 94, 16);
		panel_2.add(lblNewLabel_3);
		
		JTextPane txtpnChegadaAoAeroporto_1 = new JTextPane();
		txtpnChegadaAoAeroporto_1.setText("Na chegada, encontre seu motorista no aeroporto e prossiga para um passeio turístico em carro particular com motorista que fala inglês. Desfrute de um passeio de 2 horas pela cidade, obtendo uma visão panorâmica de Paris em seu carro de luxo. À noite, desfrute de um cruzeiro romântico com jantar no Rio Sena. Alojamento no hotel.");
		txtpnChegadaAoAeroporto_1.setForeground(Color.GRAY);
		txtpnChegadaAoAeroporto_1.setBounds(10, 173, 310, 95);
		panel_2.add(txtpnChegadaAoAeroporto_1);
		
		JLabel lblNewLabel_3_2 = new JLabel("Torre Eiffel");
		lblNewLabel_3_2.setIcon(new ImageIcon(infoparis.class.getResource("/imagens/numero-2 (1).png")));
		lblNewLabel_3_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3_2.setBounds(10, 279, 136, 23);
		panel_2.add(lblNewLabel_3_2);
		
		JTextPane txtpnCafDaManh_1 = new JTextPane();
		txtpnCafDaManh_1.setText("Café da manhã buffet no hotel. Hoje, você desfrutará de um city tour compartilhado de Paris (SIC) com entradas para a Torre Eiffel (no 2º andar). Descubra os monumentos e pontos turísticos mais famosos de Paris em um único passeio. Esta excursão é um dos melhores passeios pela Torre Eiffel e inclui uma visita ao 2º andar da Torre Eiffel com vistas deslumbrantes da capital e um passeio panorâmico pela cidade de ônibus. Este passeio combinado é a maneira ideal de descobrir Paris. Alojamento no hotel.");
		txtpnCafDaManh_1.setForeground(Color.GRAY);
		txtpnCafDaManh_1.setBounds(10, 303, 371, 100);
		panel_2.add(txtpnCafDaManh_1);
		
		JLabel lblNewLabel_3_2_1 = new JLabel("Paris, Reims, Champagney");
		lblNewLabel_3_2_1.setIcon(new ImageIcon(infoparis.class.getResource("/imagens/numero-3.png")));
		lblNewLabel_3_2_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3_2_1.setBounds(10, 421, 195, 23);
		panel_2.add(lblNewLabel_3_2_1);
		
		JTextPane txtpnCafDaManh_2 = new JTextPane();
		txtpnCafDaManh_2.setText("Café da manhã buffet no hotel. Pela manhã, dirija-se ao ponto de encontro por conta própria (será informado no voucher), para fazer um tour compartilhado pela região de Reims e Champagne, com almoço e visita à vinícola de Champagne com degustação. Saia em uma viagem para descobrir os segredos da produção de vinho. Você visitará a região de Reims e desfrutará de um almoço tradicional em Epernay (incluído).");
		txtpnCafDaManh_2.setForeground(Color.GRAY);
		txtpnCafDaManh_2.setBounds(10, 455, 371, 90);
		panel_2.add(txtpnCafDaManh_2);
		
		JLabel lblNewLabel_3_1 = new JLabel("Palácio de Versalhes");
		lblNewLabel_3_1.setIcon(new ImageIcon(infoparis.class.getResource("/imagens/numero-4 (1).png")));
		lblNewLabel_3_1.setToolTipText("DATA:");
		lblNewLabel_3_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3_1.setBounds(488, 147, 173, 16);
		panel_2.add(lblNewLabel_3_1);
		
		JTextPane txtpnChegadaAoAeroporto_1_1 = new JTextPane();
		txtpnChegadaAoAeroporto_1_1.setText("Café da manhã buffet no hotel. Hoje você viverá a França como um francês. Primeiramente, você desfrutará de um almoço gourmet local de 3 pratos com vinho francês. À tarde, desfrute de uma degustação de vinhos e queijos franceses, juntamente com charcutaria. Prove três vinhos de diferentes regiões da França e aprenda as técnicas de degustação de vinhos com seu guia especializado. Você terá tempo para experimentar a qualidade. Alojamento no hotel.");
		txtpnChegadaAoAeroporto_1_1.setForeground(Color.GRAY);
		txtpnChegadaAoAeroporto_1_1.setBounds(488, 173, 397, 100);
		panel_2.add(txtpnChegadaAoAeroporto_1_1);
		
		JLabel lblNewLabel_3_2_2 = new JLabel("Museu do Louvre");
		lblNewLabel_3_2_2.setIcon(new ImageIcon(infoparis.class.getResource("/imagens/numero-5.png")));
		lblNewLabel_3_2_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3_2_2.setBounds(488, 279, 243, 23);
		panel_2.add(lblNewLabel_3_2_2);
		
		JTextPane txtpnCafDaManh_1_1 = new JTextPane();
		txtpnCafDaManh_1_1.setText("Pela manhã, visita ao Museu do Louvrel; à Necrópole de Tebas; ao Vale dos Reis, ao Templo Funerário da Rainha Hatshepsut conhecido como O-Deir O-Bahari, e aos Colossos de Memnon. À hora prevista, zarparemos até Esna. Cruzaremos a Eclusa de Esna e continuaremos a navegação até Edfu. Pensão completa e noite a bordo.");
		txtpnCafDaManh_1_1.setForeground(Color.GRAY);
		txtpnCafDaManh_1_1.setBounds(488, 303, 371, 100);
		panel_2.add(txtpnCafDaManh_1_1);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(new Color(255, 255, 255));
		tabbedPane.addTab("SEGURO VIAGEM", null, panel_3, null);
		panel_3.setLayout(null);
		
		JLabel lblNewLabel_3_4 = new JLabel("O Que é Seguro Viagem?");
		lblNewLabel_3_4.setIcon(new ImageIcon(infoparis.class.getResource("/imagens/seguro.png")));
		lblNewLabel_3_4.setToolTipText("DATA:");
		lblNewLabel_3_4.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3_4.setBounds(10, 189, 196, 25);
		panel_3.add(lblNewLabel_3_4);
		
		JTextPane txtpnOSeguroViagem = new JTextPane();
		txtpnOSeguroViagem.setText("O Seguro Viagem oferece um conjunto de coberturas para auxiliar o passageiro durante sua viagem em caso de urgência e emergência, com questões relacionadas a por exemplo: problemas de saúde, perda/dano de bagagem, e qualquer outro evento coberto.​ Em alguns países o Seguro Viagem é obrigatório. Garanta já o seu!");
		txtpnOSeguroViagem.setForeground(Color.GRAY);
		txtpnOSeguroViagem.setBounds(10, 225, 371, 103);
		panel_3.add(txtpnOSeguroViagem);
		
		JLabel lblNewLabel_3_4_1 = new JLabel("O Que Oferece?");
		lblNewLabel_3_4_1.setIcon(new ImageIcon(infoparis.class.getResource("/imagens/seguro.png")));
		lblNewLabel_3_4_1.setToolTipText("DATA:");
		lblNewLabel_3_4_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3_4_1.setBounds(10, 334, 371, 25);
		panel_3.add(lblNewLabel_3_4_1);
		
		JLabel lblNewLabel_3_5 = new JLabel("Atendimento 24 Horas");
		lblNewLabel_3_5.setIcon(new ImageIcon(infoparis.class.getResource("/imagens/numero-1.png")));
		lblNewLabel_3_5.setToolTipText("DATA:");
		lblNewLabel_3_5.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3_5.setBounds(10, 370, 371, 16);
		panel_3.add(lblNewLabel_3_5);
		
		JTextPane txtpnLigueGratuitamenteDurante = new JTextPane();
		txtpnLigueGratuitamenteDurante.setText("Ligue gratuitamente durante a sua viagem a qualquer momento.");
		txtpnLigueGratuitamenteDurante.setForeground(Color.GRAY);
		txtpnLigueGratuitamenteDurante.setBounds(10, 399, 371, 20);
		panel_3.add(txtpnLigueGratuitamenteDurante);
		
		JLabel lblNewLabel_3_5_1 = new JLabel("Assistência Médica e Odontológica");
		lblNewLabel_3_5_1.setIcon(new ImageIcon(infoparis.class.getResource("/imagens/numero-2 (1).png")));
		lblNewLabel_3_5_1.setToolTipText("DATA:");
		lblNewLabel_3_5_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3_5_1.setBounds(10, 428, 251, 16);
		panel_3.add(lblNewLabel_3_5_1);
		
		JTextPane txtpnAtendimentoEmCaso = new JTextPane();
		txtpnAtendimentoEmCaso.setText("Atendimento em caso de urgência/emergência.");
		txtpnAtendimentoEmCaso.setForeground(Color.GRAY);
		txtpnAtendimentoEmCaso.setBounds(10, 447, 371, 20);
		panel_3.add(txtpnAtendimentoEmCaso);
		
		JLabel lblNewLabel_3_5_1_1 = new JLabel("Teleassistência Médica");
		lblNewLabel_3_5_1_1.setIcon(new ImageIcon(infoparis.class.getResource("/imagens/numero-3.png")));
		lblNewLabel_3_5_1_1.setToolTipText("DATA:");
		lblNewLabel_3_5_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3_5_1_1.setBounds(393, 370, 251, 16);
		panel_3.add(lblNewLabel_3_5_1_1);
		
		JTextPane txtpnFaaUmTele = new JTextPane();
		txtpnFaaUmTele.setText("Faça um tele atendimento sem esperar ou sair de onde você está. Inclui prescrições.");
		txtpnFaaUmTele.setForeground(Color.GRAY);
		txtpnFaaUmTele.setBounds(399, 392, 371, 34);
		panel_3.add(txtpnFaaUmTele);
		
		JLabel lblNewLabel_3_5_1_1_1 = new JLabel("Assistência Anti Perda de Bagagem");
		lblNewLabel_3_5_1_1_1.setIcon(new ImageIcon(infoparis.class.getResource("/imagens/numero-4 (1).png")));
		lblNewLabel_3_5_1_1_1.setToolTipText("DATA:");
		lblNewLabel_3_5_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3_5_1_1_1.setBounds(391, 428, 251, 16);
		panel_3.add(lblNewLabel_3_5_1_1_1);
		
		JTextPane txtpnAssistnciaEReembolso = new JTextPane();
		txtpnAssistnciaEReembolso.setText("Assistência e reembolso por extravio ou perda de bagagens.");
		txtpnAssistnciaEReembolso.setForeground(Color.GRAY);
		txtpnAssistnciaEReembolso.setBounds(391, 450, 371, 20);
		panel_3.add(txtpnAssistnciaEReembolso);
		
		JTextPane txtpnParis_1_1 = new JTextPane();
		txtpnParis_1_1.setText("Paris - 2025 \r\n\r\n\r\n");
		txtpnParis_1_1.setForeground(Color.BLACK);
		txtpnParis_1_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		txtpnParis_1_1.setBackground(Color.WHITE);
		txtpnParis_1_1.setBounds(401, 11, 152, 31);
		panel_3.add(txtpnParis_1_1);
		
		JTextPane txtpnPartidasDe_1_1_1 = new JTextPane();
		txtpnPartidasDe_1_1_1.setText("Partidas de 15 de Abril 2025 a 21 de Abril 2025\r\n\r\n\r\n");
		txtpnPartidasDe_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		txtpnPartidasDe_1_1_1.setBackground(new Color(53, 189, 255));
		txtpnPartidasDe_1_1_1.setBounds(320, 79, 310, 26);
		panel_3.add(txtpnPartidasDe_1_1_1);
		
		JSeparator separator_1_1 = new JSeparator();
		separator_1_1.setBounds(286, 62, 358, 2);
		panel_3.add(separator_1_1);
	}
}
