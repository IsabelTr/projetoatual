package projetoatv;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTabbedPane;
import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JTextPane;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Font;
import javax.swing.JSeparator;
import java.awt.FlowLayout;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Toolkit;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.net.URI;
import java.awt.event.ActionEvent;

public class infoegito {

	private JFrame frmPacoteEgito;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					infoegito window = new infoegito();
					window.frmPacoteEgito.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public infoegito() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmPacoteEgito = new JFrame();
		frmPacoteEgito.setIconImage(Toolkit.getDefaultToolkit().getImage(infoegito.class.getResource("/imagens/egito.png")));
		frmPacoteEgito.setTitle("PACOTE EGITO");
		frmPacoteEgito.setBounds(100, 100, 1311, 788);
		frmPacoteEgito.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmPacoteEgito.getContentPane().setLayout(new BorderLayout(0, 0));
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		frmPacoteEgito.getContentPane().add(tabbedPane);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		tabbedPane.addTab("SERVIÇOS INCLUSOS", null, panel, null);
		panel.setLayout(null);
		
		JTextPane txtpnEgito_3 = new JTextPane();
		txtpnEgito_3.setText("Egito Clássico + Cruzeiro pelo Rio Nilo\r\n\r\n\r\n");
		txtpnEgito_3.setForeground(Color.BLACK);
		txtpnEgito_3.setFont(new Font("Tahoma", Font.BOLD, 20));
		txtpnEgito_3.setBackground(Color.WHITE);
		txtpnEgito_3.setBounds(576, 11, 413, 31);
		panel.add(txtpnEgito_3);
		
		JSeparator separator_3 = new JSeparator();
		separator_3.setBounds(604, 53, 358, 2);
		panel.add(separator_3);
		
		JTextPane txtpnPartidasDe_1_3 = new JTextPane();
		txtpnPartidasDe_1_3.setText("Partidas de 1 de outubro 2024 a 18 de fevereiro 2025");
		txtpnPartidasDe_1_3.setFont(new Font("Tahoma", Font.PLAIN, 12));
		txtpnPartidasDe_1_3.setBackground(new Color(53, 189, 255));
		txtpnPartidasDe_1_3.setBounds(642, 66, 310, 26);
		panel.add(txtpnPartidasDe_1_3);
		
		JLabel lblNewLabel_2 = new JLabel("Passagem Aéria Econômica");
		lblNewLabel_2.setIcon(new ImageIcon(infoegito.class.getResource("/imagens/aviao (1).png")));
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2.setBackground(Color.WHITE);
		lblNewLabel_2.setBounds(10, 168, 240, 27);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel("Hospedagem + Café da Manhã");
		lblNewLabel_2_1.setIcon(new ImageIcon(infoegito.class.getResource("/imagens/cama.png")));
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2_1.setBackground(Color.WHITE);
		lblNewLabel_2_1.setBounds(363, 168, 240, 27);
		panel.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_2_1_1 = new JLabel("Passagens aéreas de ida e volta em classe econômica.");
		lblNewLabel_2_1_1.setForeground(Color.GRAY);
		lblNewLabel_2_1_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_2_1_1.setBounds(10, 193, 319, 27);
		panel.add(lblNewLabel_2_1_1);
		
		JLabel lblNewLabel_2_1_1_1 = new JLabel("Com quarto duplo ou triplo.");
		lblNewLabel_2_1_1_1.setForeground(Color.GRAY);
		lblNewLabel_2_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_2_1_1_1.setBounds(363, 201, 319, 27);
		panel.add(lblNewLabel_2_1_1_1);
		
		JLabel lblNewLabel_2_2 = new JLabel("Guia Acompanhante ");
		lblNewLabel_2_2.setIcon(new ImageIcon(infoegito.class.getResource("/imagens/guia-turistico (1).png")));
		lblNewLabel_2_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2_2.setBackground(Color.WHITE);
		lblNewLabel_2_2.setBounds(10, 231, 263, 27);
		panel.add(lblNewLabel_2_2);
		
		JLabel lblNewLabel_2_1_1_2 = new JLabel("Durante todo o trajeto.");
		lblNewLabel_2_1_1_2.setForeground(Color.GRAY);
		lblNewLabel_2_1_1_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_2_1_1_2.setBounds(10, 265, 237, 27);
		panel.add(lblNewLabel_2_1_1_2);
		
		JLabel lblNewLabel_2_2_1 = new JLabel("Transfer Local");
		lblNewLabel_2_2_1.setIcon(new ImageIcon(infoegito.class.getResource("/imagens/carros.png")));
		lblNewLabel_2_2_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2_2_1.setBackground(Color.WHITE);
		lblNewLabel_2_2_1.setBounds(363, 238, 263, 27);
		panel.add(lblNewLabel_2_2_1);
		
		JLabel lblNewLabel_2_1_1_2_1 = new JLabel("Inclui descolamento entre cidades.");
		lblNewLabel_2_1_1_2_1.setForeground(Color.GRAY);
		lblNewLabel_2_1_1_2_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_2_1_1_2_1.setBounds(363, 265, 237, 27);
		panel.add(lblNewLabel_2_1_1_2_1);
		
		JTextPane txtpnNoitesDe = new JTextPane();
		txtpnNoitesDe.setText("4 noites de hospedagem com café da manhã no Cairo;");
		txtpnNoitesDe.setFont(new Font("Tahoma", Font.BOLD, 12));
		txtpnNoitesDe.setBounds(24, 320, 426, 21);
		panel.add(txtpnNoitesDe);
		
		JTextPane txtpnNoites = new JTextPane();
		txtpnNoites.setText("Com visitas para: Luxor,Edfu,Kom Ombo e Assuã");
		txtpnNoites.setFont(new Font("Tahoma", Font.PLAIN, 12));
		txtpnNoites.setBounds(34, 464, 467, 31);
		panel.add(txtpnNoites);
		
		JTextPane txtpnNoites_1 = new JTextPane();
		txtpnNoites_1.setText(" 4 noites de cruzeiro pelo Rio Nilo ");
		txtpnNoites_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		txtpnNoites_1.setBounds(24, 435, 426, 31);
		panel.add(txtpnNoites_1);
		
		JTextPane txtpnNoites_1_1 = new JTextPane();
		txtpnNoites_1_1.setText("Visitas às três pirâmidesde Gizé, à esfinge eterna e ao templo do vale de Quéfren;");
		txtpnNoites_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		txtpnNoites_1_1.setBounds(24, 373, 426, 36);
		panel.add(txtpnNoites_1_1);
		
		JTextPane txtpnNoites_2 = new JTextPane();
		txtpnNoites_2.setText("Todos os traslados são feitos em carro com ar condicionado. ");
		txtpnNoites_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		txtpnNoites_2.setBounds(34, 342, 467, 31);
		panel.add(txtpnNoites_2);
		
		JTextPane txtpnNoites_2_1 = new JTextPane();
		txtpnNoites_2_1.setText("Guia acompanhante em PORTUGUÊS! Durante todo o roteiro");
		txtpnNoites_2_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		txtpnNoites_2_1.setBounds(34, 415, 467, 21);
		panel.add(txtpnNoites_2_1);
		
		JTextPane txtpnNoites_1_2 = new JTextPane();
		txtpnNoites_1_2.setText("Visto de entrada no Egito ");
		txtpnNoites_1_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		txtpnNoites_1_2.setBounds(24, 495, 426, 31);
		panel.add(txtpnNoites_1_2);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(infoegito.class.getResource("/imagens/capa-ftcmag-pontos-turisticos-do-egito (1).png")));
		lblNewLabel_1.setBounds(657, 373, 300, 202);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("");
		lblNewLabel_1_1.setIcon(new ImageIcon(infoegito.class.getResource("/imagens/cruzeiros-para-o-egito (1).jpg")));
		lblNewLabel_1_1.setBounds(657, 150, 300, 202);
		panel.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(infoegito.class.getResource("/imagens/istockphoto-506604108-612x612 (1).jpg")));
		lblNewLabel.setBounds(980, 110, 300, 430);
		panel.add(lblNewLabel);
		
		JButton btnExploreEgito = new JButton("EXPLORE EGITO");
		btnExploreEgito.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String url = "https://www.google.com/maps/place/Egito/data=!4m2!3m1!1s0x14368976c35c36e9:0x2c45a00925c4c444?sa=X&ved=1t:242&ictx=111";
					if (Desktop.isDesktopSupported()) {
						Desktop desktop = Desktop.getDesktop();
						desktop.browse(new URI(url));
					} else {
						System.out.println("Desktop não suportado.");
					}
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		});
		btnExploreEgito.setBounds(164, 552, 199, 23);
		panel.add(btnExploreEgito);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(255, 255, 255));
		tabbedPane.addTab("SERVIÇOS NÃO INCLUSOS", null, panel_1, null);
		panel_1.setLayout(null);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setBounds(650, 53, 358, 2);
		panel_1.add(separator_2);
		
		JTextPane txtpnEgito_3_1 = new JTextPane();
		txtpnEgito_3_1.setText("Egito Clássico + Cruzeiro pelo Rio Nilo\r\n\r\n\r\n");
		txtpnEgito_3_1.setForeground(Color.BLACK);
		txtpnEgito_3_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		txtpnEgito_3_1.setBackground(Color.WHITE);
		txtpnEgito_3_1.setBounds(564, 11, 413, 31);
		panel_1.add(txtpnEgito_3_1);
		
		JTextPane txtpnPartidasDe_1_3_1 = new JTextPane();
		txtpnPartidasDe_1_3_1.setText("Partidas de 1 de outubro 2024 a 18 de fevereiro 2025");
		txtpnPartidasDe_1_3_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		txtpnPartidasDe_1_3_1.setBackground(new Color(53, 189, 255));
		txtpnPartidasDe_1_3_1.setBounds(680, 66, 310, 26);
		panel_1.add(txtpnPartidasDe_1_3_1);
		
		JLabel lblNewLabel_3_3 = new JLabel("Taxas de turismo de entrada/saída cobradas localmente;");
		lblNewLabel_3_3.setIcon(new ImageIcon(infoegito.class.getResource("/imagens/numero-1.png")));
		lblNewLabel_3_3.setToolTipText("DATA:");
		lblNewLabel_3_3.setForeground(Color.GRAY);
		lblNewLabel_3_3.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_3_3.setBounds(10, 155, 346, 16);
		panel_1.add(lblNewLabel_3_3);
		
		JLabel lblNewLabel_3_3_1 = new JLabel("Taxas governamentais locais cobradas através dos hotéis;");
		lblNewLabel_3_3_1.setIcon(new ImageIcon(infoegito.class.getResource("/imagens/numero-2 (1).png")));
		lblNewLabel_3_3_1.setToolTipText("DATA:");
		lblNewLabel_3_3_1.setForeground(Color.GRAY);
		lblNewLabel_3_3_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_3_3_1.setBounds(10, 189, 323, 16);
		panel_1.add(lblNewLabel_3_3_1);
		
		JLabel lblNewLabel_3_3_1_1 = new JLabel("Gorjetas a guias, motoristas e garçons;");
		lblNewLabel_3_3_1_1.setIcon(new ImageIcon(infoegito.class.getResource("/imagens/numero-5.png")));
		lblNewLabel_3_3_1_1.setToolTipText("DATA:");
		lblNewLabel_3_3_1_1.setForeground(Color.GRAY);
		lblNewLabel_3_3_1_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_3_3_1_1.setBounds(446, 189, 271, 16);
		panel_1.add(lblNewLabel_3_3_1_1);
		
		JLabel lblNewLabel_3_3_1_1_1 = new JLabel("Refeições e bebidas não mencionadas como incluídas;");
		lblNewLabel_3_3_1_1_1.setIcon(new ImageIcon(infoegito.class.getResource("/imagens/numero-4 (1).png")));
		lblNewLabel_3_3_1_1_1.setToolTipText("DATA:");
		lblNewLabel_3_3_1_1_1.setForeground(Color.GRAY);
		lblNewLabel_3_3_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_3_3_1_1_1.setBounds(446, 155, 323, 16);
		panel_1.add(lblNewLabel_3_3_1_1_1);
		
		JLabel lblNewLabel_3_3_1_1_1_3 = new JLabel("Despesas de caráter pessoal como:");
		lblNewLabel_3_3_1_1_1_3.setIcon(new ImageIcon(infoegito.class.getResource("/imagens/numero-3.png")));
		lblNewLabel_3_3_1_1_1_3.setToolTipText("DATA:");
		lblNewLabel_3_3_1_1_1_3.setForeground(Color.GRAY);
		lblNewLabel_3_3_1_1_1_3.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_3_3_1_1_1_3.setBounds(10, 216, 323, 36);
		panel_1.add(lblNewLabel_3_3_1_1_1_3);
		
		JLabel lblNewLabel_3_3_1_1_1_1 = new JLabel("Qualquer item não mencionado como incluído.");
		lblNewLabel_3_3_1_1_1_1.setIcon(new ImageIcon(infoegito.class.getResource("/imagens/numero-6.png")));
		lblNewLabel_3_3_1_1_1_1.setToolTipText("DATA:");
		lblNewLabel_3_3_1_1_1_1.setForeground(Color.GRAY);
		lblNewLabel_3_3_1_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_3_3_1_1_1_1.setBounds(446, 226, 320, 16);
		panel_1.add(lblNewLabel_3_3_1_1_1_1);
		
		JLabel lblNewLabel_3_3_1_2 = new JLabel(" telefonemas, lavanderia, utilização de frigobar e excesso de bagagem\r\n");
		lblNewLabel_3_3_1_2.setToolTipText("DATA:");
		lblNewLabel_3_3_1_2.setForeground(Color.GRAY);
		lblNewLabel_3_3_1_2.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblNewLabel_3_3_1_2.setBounds(10, 245, 381, 31);
		panel_1.add(lblNewLabel_3_3_1_2);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(255, 255, 255));
		tabbedPane.addTab("ROTEIRO", null, panel_2, null);
		panel_2.setLayout(null);
		
		JTextPane txtpnEgito_3_1_1 = new JTextPane();
		txtpnEgito_3_1_1.setText("Egito Clássico + Cruzeiro pelo Rio Nilo\r\n\r\n\r\n");
		txtpnEgito_3_1_1.setForeground(Color.BLACK);
		txtpnEgito_3_1_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		txtpnEgito_3_1_1.setBackground(Color.WHITE);
		txtpnEgito_3_1_1.setBounds(487, 11, 413, 31);
		panel_2.add(txtpnEgito_3_1_1);
		
		JSeparator separator_2_1 = new JSeparator();
		separator_2_1.setBounds(573, 53, 358, 2);
		panel_2.add(separator_2_1);
		
		JTextPane txtpnPartidasDe_1_3_1_1 = new JTextPane();
		txtpnPartidasDe_1_3_1_1.setText("Partidas de 1 de outubro 2024 a 18 de fevereiro 2025");
		txtpnPartidasDe_1_3_1_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		txtpnPartidasDe_1_3_1_1.setBackground(new Color(53, 189, 255));
		txtpnPartidasDe_1_3_1_1.setBounds(603, 66, 310, 26);
		panel_2.add(txtpnPartidasDe_1_3_1_1);
		
		JLabel lblNewLabel_3 = new JLabel("Cairo");
		lblNewLabel_3.setIcon(new ImageIcon(infoegito.class.getResource("/imagens/numero-1.png")));
		lblNewLabel_3.setToolTipText("DATA:");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3.setBounds(25, 127, 94, 16);
		panel_2.add(lblNewLabel_3);
		
		JTextPane txtpnChegadaAoAeroporto_1 = new JTextPane();
		txtpnChegadaAoAeroporto_1.setText("Chegada ao aeroporto internacional do Cairo, assistência em língua portuguesa no aeroporto pelo nosso representante antes do controle de passaporte. Traslado para o hotel e pernoite. Os apartamentos estarão disponíveis após as 16h.");
		txtpnChegadaAoAeroporto_1.setForeground(Color.GRAY);
		txtpnChegadaAoAeroporto_1.setBounds(25, 153, 310, 95);
		panel_2.add(txtpnChegadaAoAeroporto_1);
		
		JLabel lblNewLabel_3_2 = new JLabel("Cairo");
		lblNewLabel_3_2.setIcon(new ImageIcon(infoegito.class.getResource("/imagens/numero-2 (1).png")));
		lblNewLabel_3_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3_2.setBounds(25, 259, 136, 23);
		panel_2.add(lblNewLabel_3_2);
		
		JTextPane txtpnCafDaManh_1 = new JTextPane();
		txtpnCafDaManh_1.setText("Café da manhã. Dia inteiro das visitas à cidade do Cairo com visita ao Museu Egípcio da Arte Faraônica, à Cidadela do Saladino com sua Mesquita de Alabastro de Muhammad Ali, ao Bairro Copta e ao Mercardo de Khan El-Khalili. À noite, possibilidade de realizar visita opcional de jantar com show folclórico no barco flutuante pelo Rio Nilo. Regresso ao hotel e hospedagem.");
		txtpnCafDaManh_1.setForeground(Color.GRAY);
		txtpnCafDaManh_1.setBounds(25, 283, 371, 100);
		panel_2.add(txtpnCafDaManh_1);
		
		JLabel lblNewLabel_3_2_1 = new JLabel("Cairo, Luxor");
		lblNewLabel_3_2_1.setIcon(new ImageIcon(infoegito.class.getResource("/imagens/numero-3.png")));
		lblNewLabel_3_2_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3_2_1.setBounds(25, 401, 195, 23);
		panel_2.add(lblNewLabel_3_2_1);
		
		JTextPane txtpnCafDaManh_2 = new JTextPane();
		txtpnCafDaManh_2.setText("Café da manhã. Meio dia de visitas à Necrópole de Gizé; formadas pelas Três Pirâmides de Quéops, Quéfren e Miquerinos, à Esfinge Eterna e ao Templo do Vale de Quéfren (não inclui entrada para o interior das Pirâmides). Pela tarde, possibilidade de realizar visita opcional à Necrópole de Saqqara e à cidade de Memphis, Capital do Antigo Império. Resto do dia livre e hospedagem.");
		txtpnCafDaManh_2.setForeground(Color.GRAY);
		txtpnCafDaManh_2.setBounds(25, 435, 371, 90);
		panel_2.add(txtpnCafDaManh_2);
		
		JLabel lblNewLabel_3_1 = new JLabel("Kom Ombo, Assuã");
		lblNewLabel_3_1.setIcon(new ImageIcon(infoegito.class.getResource("/imagens/numero-4 (1).png")));
		lblNewLabel_3_1.setToolTipText("DATA:");
		lblNewLabel_3_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3_1.setBounds(503, 127, 173, 16);
		panel_2.add(lblNewLabel_3_1);
		
		JTextPane txtpnChegadaAoAeroporto_1_1 = new JTextPane();
		txtpnChegadaAoAeroporto_1_1.setText("Pela manhã, possibilidade de realizar excursão aos  Templos de Abu Simbel. Também, se empreenderá um passeio em uma Faluca pelo Rio Nilo (típicos veleiros egípcios) desde onde poderemos admirar e desfrutar de uma vista panorâmica ao Mausoléu do Agha Khan, à Ilha Elefantina e ao Jardim Botânico. À continuação, visita à Represa Alta de Assuão e ao Templo de Filae. Pensão completa e noite a bordo.");
		txtpnChegadaAoAeroporto_1_1.setForeground(Color.GRAY);
		txtpnChegadaAoAeroporto_1_1.setBounds(503, 153, 397, 100);
		panel_2.add(txtpnChegadaAoAeroporto_1_1);
		
		JLabel lblNewLabel_3_2_2 = new JLabel("Luxor, Esna, Edfu [Behedet]");
		lblNewLabel_3_2_2.setIcon(new ImageIcon(infoegito.class.getResource("/imagens/numero-5.png")));
		lblNewLabel_3_2_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3_2_2.setBounds(503, 259, 243, 23);
		panel_2.add(lblNewLabel_3_2_2);
		
		JTextPane txtpnCafDaManh_1_1 = new JTextPane();
		txtpnCafDaManh_1_1.setText("Pela manhã, visita à Margem Ocidental em Luxor; à Necrópole de Tebas; ao Vale dos Reis, ao Templo Funerário da Rainha Hatshepsut conhecido como O-Deir O-Bahari, e aos Colossos de Memnon. À hora prevista, zarparemos até Esna. Cruzaremos a Eclusa de Esna e continuaremos a navegação até Edfu. Pensão completa e noite a bordo.");
		txtpnCafDaManh_1_1.setForeground(Color.GRAY);
		txtpnCafDaManh_1_1.setBounds(503, 283, 371, 100);
		panel_2.add(txtpnCafDaManh_1_1);
		
		JLabel lblNewLabel_3_2_1_1 = new JLabel("Cairo");
		lblNewLabel_3_2_1_1.setIcon(new ImageIcon(infoegito.class.getResource("/imagens/numero-6.png")));
		lblNewLabel_3_2_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3_2_1_1.setBounds(503, 401, 195, 23);
		panel_2.add(lblNewLabel_3_2_1_1);
		
		JTextPane txtpnCafDaManh_2_1 = new JTextPane();
		txtpnCafDaManh_2_1.setText("Café da manhã. Os apartamentos estarão disponíveis até as 12h. À hora prevista, traslado para o aeroporto internacional do Cairo, assistência em língua portuguesa no aeroporto pelo nosso representante. Fim de Nossos Serviços.");
		txtpnCafDaManh_2_1.setForeground(Color.GRAY);
		txtpnCafDaManh_2_1.setBounds(503, 435, 371, 90);
		panel_2.add(txtpnCafDaManh_2_1);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(new Color(255, 255, 255));
		tabbedPane.addTab("SEGURO VIAGEM", null, panel_3, null);
		panel_3.setLayout(null);
		
		JTextPane txtpnEgito_3_2 = new JTextPane();
		txtpnEgito_3_2.setText("Egito Clássico + Cruzeiro pelo Rio Nilo\r\n\r\n\r\n");
		txtpnEgito_3_2.setForeground(Color.BLACK);
		txtpnEgito_3_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		txtpnEgito_3_2.setBackground(Color.WHITE);
		txtpnEgito_3_2.setBounds(525, 11, 413, 31);
		panel_3.add(txtpnEgito_3_2);
		
		JSeparator separator_3_1 = new JSeparator();
		separator_3_1.setBounds(553, 53, 358, 2);
		panel_3.add(separator_3_1);
		
		JTextPane txtpnPartidasDe_1_3_2 = new JTextPane();
		txtpnPartidasDe_1_3_2.setText("Partidas de 1 de outubro 2024 a 18 de fevereiro 2025");
		txtpnPartidasDe_1_3_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		txtpnPartidasDe_1_3_2.setBackground(new Color(53, 189, 255));
		txtpnPartidasDe_1_3_2.setBounds(591, 66, 310, 26);
		panel_3.add(txtpnPartidasDe_1_3_2);
		
		JPanel panel_3_1 = new JPanel();
		panel_3_1.setLayout(null);
		panel_3_1.setBackground(Color.WHITE);
		panel_3_1.setBounds(-11, 0, 1133, 721);
		panel_3.add(panel_3_1);
		
		JLabel lblNewLabel_3_4 = new JLabel("O Que é Seguro Viagem?");
		lblNewLabel_3_4.setIcon(new ImageIcon(infoegito.class.getResource("/imagens/seguro.png")));
		lblNewLabel_3_4.setToolTipText("DATA:");
		lblNewLabel_3_4.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3_4.setBounds(10, 189, 196, 25);
		panel_3_1.add(lblNewLabel_3_4);
		
		JTextPane txtpnOSeguroViagem = new JTextPane();
		txtpnOSeguroViagem.setText("O Seguro Viagem oferece um conjunto de coberturas para auxiliar o passageiro durante sua viagem em caso de urgência e emergência, com questões relacionadas a por exemplo: problemas de saúde, perda/dano de bagagem, e qualquer outro evento coberto.​ Em alguns países o Seguro Viagem é obrigatório. Garanta já o seu!");
		txtpnOSeguroViagem.setForeground(Color.GRAY);
		txtpnOSeguroViagem.setBounds(10, 225, 371, 103);
		panel_3_1.add(txtpnOSeguroViagem);
		
		JLabel lblNewLabel_3_4_1 = new JLabel("O Que Oferece?");
		lblNewLabel_3_4_1.setIcon(new ImageIcon(infoegito.class.getResource("/imagens/seguro.png")));
		lblNewLabel_3_4_1.setToolTipText("DATA:");
		lblNewLabel_3_4_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3_4_1.setBounds(10, 334, 371, 25);
		panel_3_1.add(lblNewLabel_3_4_1);
		
		JLabel lblNewLabel_3_5 = new JLabel("Atendimento 24 Horas");
		lblNewLabel_3_5.setIcon(new ImageIcon(infoegito.class.getResource("/imagens/numero-1.png")));
		lblNewLabel_3_5.setToolTipText("DATA:");
		lblNewLabel_3_5.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3_5.setBounds(10, 370, 371, 16);
		panel_3_1.add(lblNewLabel_3_5);
		
		JTextPane txtpnLigueGratuitamenteDurante = new JTextPane();
		txtpnLigueGratuitamenteDurante.setText("Ligue gratuitamente durante a sua viagem a qualquer momento.");
		txtpnLigueGratuitamenteDurante.setForeground(Color.GRAY);
		txtpnLigueGratuitamenteDurante.setBounds(10, 399, 371, 20);
		panel_3_1.add(txtpnLigueGratuitamenteDurante);
		
		JLabel lblNewLabel_3_5_1 = new JLabel("Assistência Médica e Odontológica");
		lblNewLabel_3_5_1.setIcon(new ImageIcon(infoegito.class.getResource("/imagens/numero-2 (1).png")));
		lblNewLabel_3_5_1.setToolTipText("DATA:");
		lblNewLabel_3_5_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3_5_1.setBounds(10, 428, 251, 16);
		panel_3_1.add(lblNewLabel_3_5_1);
		
		JTextPane txtpnAtendimentoEmCaso = new JTextPane();
		txtpnAtendimentoEmCaso.setText("Atendimento em caso de urgência/emergência.");
		txtpnAtendimentoEmCaso.setForeground(Color.GRAY);
		txtpnAtendimentoEmCaso.setBounds(10, 447, 371, 20);
		panel_3_1.add(txtpnAtendimentoEmCaso);
		
		JLabel lblNewLabel_3_5_1_1 = new JLabel("Teleassistência Médica");
		lblNewLabel_3_5_1_1.setIcon(new ImageIcon(infoegito.class.getResource("/imagens/numero-3.png")));
		lblNewLabel_3_5_1_1.setToolTipText("DATA:");
		lblNewLabel_3_5_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3_5_1_1.setBounds(393, 370, 251, 16);
		panel_3_1.add(lblNewLabel_3_5_1_1);
		
		JTextPane txtpnFaaUmTele = new JTextPane();
		txtpnFaaUmTele.setText("Faça um tele atendimento sem esperar ou sair de onde você está. Inclui prescrições.");
		txtpnFaaUmTele.setForeground(Color.GRAY);
		txtpnFaaUmTele.setBounds(399, 392, 371, 34);
		panel_3_1.add(txtpnFaaUmTele);
		
		JLabel lblNewLabel_3_5_1_1_1 = new JLabel("Assistência Anti Perda de Bagagem");
		lblNewLabel_3_5_1_1_1.setIcon(new ImageIcon(infoegito.class.getResource("/imagens/numero-4 (1).png")));
		lblNewLabel_3_5_1_1_1.setToolTipText("DATA:");
		lblNewLabel_3_5_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3_5_1_1_1.setBounds(391, 428, 251, 16);
		panel_3_1.add(lblNewLabel_3_5_1_1_1);
		
		JTextPane txtpnAssistnciaEReembolso = new JTextPane();
		txtpnAssistnciaEReembolso.setText("Assistência e reembolso por extravio ou perda de bagagens.");
		txtpnAssistnciaEReembolso.setForeground(Color.GRAY);
		txtpnAssistnciaEReembolso.setBounds(391, 450, 371, 20);
		panel_3_1.add(txtpnAssistnciaEReembolso);
	}
}
