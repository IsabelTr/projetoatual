package projetoatv;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextPane;
import java.awt.BorderLayout;
import java.awt.Font;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTree;
import javax.swing.JScrollPane;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JList;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.JSeparator;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.Component;
import java.awt.Desktop;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.net.URI;
import java.awt.event.ActionEvent;
import javax.swing.JCheckBoxMenuItem;
import java.awt.Toolkit;

public class infoitalia {

	private JFrame frmPacoteItlia;
	protected Object frmPacoteparis;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					infoitalia window = new infoitalia();
					window.frmPacoteItlia.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public infoitalia() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmPacoteItlia = new JFrame();
		frmPacoteItlia.setIconImage(Toolkit.getDefaultToolkit().getImage(infoitalia.class.getResource("/imagens/italia.png")));
		frmPacoteItlia.setTitle("PACOTE ITÁLIA");
		frmPacoteItlia.setBounds(100, 100, 1658, 825);
		frmPacoteItlia.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmPacoteItlia.getContentPane().setLayout(new BorderLayout(0, 0));
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBackground(new Color(111, 208, 255));
		frmPacoteItlia.getContentPane().add(tabbedPane);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(new Color(255, 255, 255));
		tabbedPane.addTab("SERVIÇOS NÃO INCLUSOS", null, panel_3, null);
		
		JTextPane txtpnEncantosDoSul_2 = new JTextPane();
		txtpnEncantosDoSul_2.setText("Sul da Itália + Roma - 2025 \r\n\r\n\r\n");
		txtpnEncantosDoSul_2.setForeground(Color.BLACK);
		txtpnEncantosDoSul_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		txtpnEncantosDoSul_2.setBackground(Color.WHITE);
		
		JSeparator separator_2 = new JSeparator();
		
		JTextPane txtpnPartidasDe_2 = new JTextPane();
		txtpnPartidasDe_2.setText("Partidas de 4 de outubro 2025 a 12 de outubro 2025\r\n\r\n\r\n");
		txtpnPartidasDe_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		txtpnPartidasDe_2.setBackground(new Color(53, 189, 255));
		
		JLabel lblNewLabel_3_3 = new JLabel("Refeições não mencionadas.");
		lblNewLabel_3_3.setForeground(new Color(128, 128, 128));
		lblNewLabel_3_3.setIcon(new ImageIcon(infoitalia.class.getResource("/imagens/numero-1.png")));
		lblNewLabel_3_3.setToolTipText("DATA:");
		lblNewLabel_3_3.setFont(new Font("Tahoma", Font.PLAIN, 12));
		
		JLabel lblNewLabel_3_3_1 = new JLabel("Seguro assistência saúde/bagagem.");
		lblNewLabel_3_3_1.setIcon(new ImageIcon(infoitalia.class.getResource("/imagens/numero-2 (1).png")));
		lblNewLabel_3_3_1.setToolTipText("DATA:");
		lblNewLabel_3_3_1.setForeground(Color.GRAY);
		lblNewLabel_3_3_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		
		JLabel lblNewLabel_3_3_1_1 = new JLabel("Extras de caráter pessoal\r\n");
		lblNewLabel_3_3_1_1.setIcon(new ImageIcon(infoitalia.class.getResource("/imagens/numero-3.png")));
		lblNewLabel_3_3_1_1.setToolTipText("DATA:");
		lblNewLabel_3_3_1_1.setForeground(Color.GRAY);
		lblNewLabel_3_3_1_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		
		JLabel lblNewLabel_3_3_1_1_1 = new JLabel("Taxas aeroportuárias nacionais e internacionais.");
		lblNewLabel_3_3_1_1_1.setIcon(new ImageIcon(infoitalia.class.getResource("/imagens/numero-4 (1).png")));
		lblNewLabel_3_3_1_1_1.setToolTipText("DATA:");
		lblNewLabel_3_3_1_1_1.setForeground(Color.GRAY);
		lblNewLabel_3_3_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		
		JLabel lblNewLabel_3_3_1_1_1_1 = new JLabel("Qualquer item não mencionado como incluído.");
		lblNewLabel_3_3_1_1_1_1.setIcon(new ImageIcon(infoitalia.class.getResource("/imagens/numero-6.png")));
		lblNewLabel_3_3_1_1_1_1.setToolTipText("DATA:");
		lblNewLabel_3_3_1_1_1_1.setForeground(Color.GRAY);
		lblNewLabel_3_3_1_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		
		JLabel lblNewLabel_3_3_1_1_1_3 = new JLabel("Excesso de bagagem.");
		lblNewLabel_3_3_1_1_1_3.setIcon(new ImageIcon(infoitalia.class.getResource("/imagens/numero-5.png")));
		lblNewLabel_3_3_1_1_1_3.setToolTipText("DATA:");
		lblNewLabel_3_3_1_1_1_3.setForeground(Color.GRAY);
		lblNewLabel_3_3_1_1_1_3.setFont(new Font("Tahoma", Font.PLAIN, 12));
		
		JLabel lblNewLabel_3_3_1_1_2 = new JLabel("(telefonemas, bebidas, lavanderia).");
		lblNewLabel_3_3_1_1_2.setToolTipText("DATA:");
		lblNewLabel_3_3_1_1_2.setForeground(Color.GRAY);
		lblNewLabel_3_3_1_1_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		GroupLayout gl_panel_3 = new GroupLayout(panel_3);
		gl_panel_3.setHorizontalGroup(
			gl_panel_3.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_3.createSequentialGroup()
					.addGroup(gl_panel_3.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel_3.createSequentialGroup()
							.addGap(408)
							.addComponent(txtpnEncantosDoSul_2, GroupLayout.PREFERRED_SIZE, 329, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel_3.createSequentialGroup()
							.addGap(371)
							.addComponent(separator_2, GroupLayout.PREFERRED_SIZE, 358, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel_3.createSequentialGroup()
							.addGap(398)
							.addComponent(txtpnPartidasDe_2, GroupLayout.PREFERRED_SIZE, 310, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel_3.createSequentialGroup()
							.addContainerGap()
							.addComponent(lblNewLabel_3_3, GroupLayout.PREFERRED_SIZE, 271, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(lblNewLabel_3_3_1_1_1, GroupLayout.PREFERRED_SIZE, 323, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel_3.createSequentialGroup()
							.addContainerGap()
							.addComponent(lblNewLabel_3_3_1, GroupLayout.PREFERRED_SIZE, 271, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(lblNewLabel_3_3_1_1_1_3, GroupLayout.PREFERRED_SIZE, 271, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel_3.createSequentialGroup()
							.addContainerGap()
							.addGroup(gl_panel_3.createParallelGroup(Alignment.TRAILING)
								.addGroup(gl_panel_3.createSequentialGroup()
									.addComponent(lblNewLabel_3_3_1_1, GroupLayout.PREFERRED_SIZE, 271, GroupLayout.PREFERRED_SIZE)
									.addGap(18))
								.addGroup(gl_panel_3.createSequentialGroup()
									.addComponent(lblNewLabel_3_3_1_1_2, GroupLayout.PREFERRED_SIZE, 271, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.UNRELATED)))
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(lblNewLabel_3_3_1_1_1_1, GroupLayout.PREFERRED_SIZE, 290, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(6744, Short.MAX_VALUE))
		);
		gl_panel_3.setVerticalGroup(
			gl_panel_3.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_3.createSequentialGroup()
					.addContainerGap()
					.addComponent(txtpnEncantosDoSul_2, GroupLayout.PREFERRED_SIZE, 32, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(separator_2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(txtpnPartidasDe_2, GroupLayout.PREFERRED_SIZE, 26, GroupLayout.PREFERRED_SIZE)
					.addGap(55)
					.addGroup(gl_panel_3.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_3_3, GroupLayout.PREFERRED_SIZE, 16, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_3_3_1_1_1, GroupLayout.PREFERRED_SIZE, 16, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_panel_3.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_3_3_1, GroupLayout.PREFERRED_SIZE, 16, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_3_3_1_1_1_3, GroupLayout.PREFERRED_SIZE, 16, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_panel_3.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_3_3_1_1, GroupLayout.PREFERRED_SIZE, 16, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_3_3_1_1_1_1, GroupLayout.PREFERRED_SIZE, 16, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(lblNewLabel_3_3_1_1_2, GroupLayout.PREFERRED_SIZE, 16, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(1061, Short.MAX_VALUE))
		);
		panel_3.setLayout(gl_panel_3);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		tabbedPane.addTab("ROTEIRO", null, panel, null);
		
		JTextPane txtpnEncantosDoSul_1 = new JTextPane();
		txtpnEncantosDoSul_1.setBounds(471, 11, 596, 40);
		txtpnEncantosDoSul_1.setText("Sul da Itália + Roma - 2025 \r\n\r\n\r\n");
		txtpnEncantosDoSul_1.setForeground(Color.BLACK);
		txtpnEncantosDoSul_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		txtpnEncantosDoSul_1.setBackground(Color.WHITE);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(438, 57, 358, 2);
		
		JTextPane txtpnPartidasDe_1 = new JTextPane();
		txtpnPartidasDe_1.setBounds(469, 77, 310, 26);
		txtpnPartidasDe_1.setText("Partidas de 4 de outubro 2025 a 12 de outubro 2025\r\n\r\n\r\n");
		txtpnPartidasDe_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		txtpnPartidasDe_1.setBackground(new Color(53, 189, 255));
		
		JLabel lblNewLabel_2_3 = new JLabel("ROTEIRO:");
		lblNewLabel_2_3.setBounds(23, 137, 110, 27);
		lblNewLabel_2_3.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_2_3.setBackground(Color.WHITE);
		
		JLabel lblNewLabel_3 = new JLabel("Itália, Roma");
		lblNewLabel_3.setBounds(23, 218, 94, 16);
		lblNewLabel_3.setToolTipText("DATA:");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3.setIcon(new ImageIcon(infoitalia.class.getResource("/imagens/numero-1.png")));
		
		JTextPane txtpnChegadaAoAeroporto = new JTextPane();
		txtpnChegadaAoAeroporto.setBounds(23, 244, 278, 48);
		txtpnChegadaAoAeroporto.setForeground(new Color(128, 128, 128));
		txtpnChegadaAoAeroporto.setText("Chegada ao aeroporto e traslado compartilhado com outros passageiros para o hotel. Os apartamentos estarão disponíveis após as 16h. Alojamento.");
		
		JLabel lblNewLabel_3_1 = new JLabel("DIAS:");
		lblNewLabel_3_1.setBounds(10, 181, 94, 16);
		lblNewLabel_3_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		
		JLabel lblNewLabel_3_2 = new JLabel("Roma");
		lblNewLabel_3_2.setBounds(23, 350, 136, 23);
		lblNewLabel_3_2.setIcon(new ImageIcon(infoitalia.class.getResource("/imagens/numero-2 (1).png")));
		lblNewLabel_3_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		
		JTextPane txtpnCafDaManh = new JTextPane();
		txtpnCafDaManh.setBounds(23, 374, 371, 100);
		txtpnCafDaManh.setText("Café da manhã no hotel. Pela manhã, tempo livre para visitar por conta própria uma parte da cidade de Roma. Possibilidade de assistir opcionalmente à Bênção Papal. À tarde faremos um passeio panorâmico a pé pela Roma Barroca onde visitaremos as fontes e praças mais emblemáticas da cidade, como a Piazza del Pantheon ou Piazza Navona, a Fonte de Trevi, etc. Alojamento.");
		txtpnCafDaManh.setForeground(new Color(128, 128, 128));
		
		JLabel lblNewLabel_3_2_1 = new JLabel("Roma, Pompei, Sorrento");
		lblNewLabel_3_2_1.setBounds(23, 492, 195, 23);
		lblNewLabel_3_2_1.setIcon(new ImageIcon(infoitalia.class.getResource("/imagens/numero-3.png")));
		lblNewLabel_3_2_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		
		JLabel lblNewLabel_3_2_1_1 = new JLabel("Sorrento, Capri");
		lblNewLabel_3_2_1_1.setBounds(580, 207, 162, 23);
		lblNewLabel_3_2_1_1.setIcon(new ImageIcon(infoitalia.class.getResource("/imagens/numero-4 (1).png")));
		lblNewLabel_3_2_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		
		JTextPane txtpnCafDaManh_2_1 = new JTextPane();
		txtpnCafDaManh_2_1.setBounds(580, 236, 383, 100);
		txtpnCafDaManh_2_1.setText("Café da manhã no hotel. Saída ao porto de Sorrento para embarque no ferry regular que nos levará à magnífica ilha de Capri, local de descanso dos imperadores romanos, que surpreende pela sua paisagem de falésias e grutas. Os destaques incluem a Marina Grande e os vários pontos turísticos de onde você pode desfrutar de vistas espetaculares. Retorno em Jet Foil para Sorrento. Jantar e pernoite no hotel.");
		txtpnCafDaManh_2_1.setForeground(Color.GRAY);
		
		JLabel lblNewLabel_3_2_1_1_1 = new JLabel("Sorrento, Costa Amalfi, Salerno");
		lblNewLabel_3_2_1_1_1.setBounds(580, 342, 230, 23);
		lblNewLabel_3_2_1_1_1.setIcon(new ImageIcon(infoitalia.class.getResource("/imagens/numero-5.png")));
		lblNewLabel_3_2_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		
		JLabel lblNewLabel_3_2_1_1_1_1 = new JLabel("Salerno, Napoles");
		lblNewLabel_3_2_1_1_1_1.setBounds(580, 492, 230, 23);
		lblNewLabel_3_2_1_1_1_1.setIcon(new ImageIcon(infoitalia.class.getResource("/imagens/numero-6.png")));
		lblNewLabel_3_2_1_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		
		JTextPane txtpnCafDaManh_2 = new JTextPane();
		txtpnCafDaManh_2.setBounds(23, 526, 371, 90);
		txtpnCafDaManh_2.setText("Café da manhã no hotel. Saída para Pompéia, onde visitaremos as escavações desta famosa cidade que foi completamente soterrada por uma erupção do Vesúvio no ano 79 DC Chegada a Sorrento e visita da cidade com suas ruas típicas. Jantar e pernoite no hotel.");
		txtpnCafDaManh_2.setForeground(Color.GRAY);
		
		JTextPane txtpnCafDaManh_2_1_1 = new JTextPane();
		txtpnCafDaManh_2_1_1.setBounds(580, 374, 451, 100);
		txtpnCafDaManh_2_1_1.setText("Café da manhã no hotel. Saída pela famosa estrada panorâmica da Costa Amalfitana em direção a Amalfi. Da estrada panorâmica podemos admirar a cidade de Positano bem como ótimas visitas ao Golfo de Nápoles. Chegada a Amalfi e visita da cidade. Continue para Salerno, segunda cidade mais importante da Campânia e visite panorâmica onde podemos apreciar locais como o Castelo, a Igreja de San Pietro a Corte, o Teatro Verdi ou a Catedral de San Matteo. Jantar e alojamento.");
		txtpnCafDaManh_2_1_1.setForeground(Color.GRAY);
		
		JTextPane txtpnCafDaManh_2_1_1_1 = new JTextPane();
		txtpnCafDaManh_2_1_1_1.setBounds(580, 515, 512, 113);
		txtpnCafDaManh_2_1_1_1.setText("Café da manhã no hotel. Saída em direção a Nápoles. À chegada faremos um passeio panorâmico pela que foi a Capital do Reino das Duas Sicílias, começando pela colina das Vómero, passando pelo calçadão, percorreremos o centro histórico da cidade com monumentos como o Teatro San Carlos, o Palácio Real, o Castelo Novo, a Praça do Plebiscito, etc. Visitaremos também a pé com guia local o centro histórico da cidade onde visitaremos a Capela de San Severo famosa por sua obra-prima: o Cristo Velado. Esta noite saudaremos o Sul de Itália com um jantar de despedida numa pizzaria do centro de Nápoles, já que este prato, famoso em todo o mundo, nasceu na cidade de Nápoles. Retorno para o hotel. Alojamento.");
		txtpnCafDaManh_2_1_1_1.setForeground(Color.GRAY);
		
		JLabel lblNewLabel_3_2_1_1_1_1_1 = new JLabel("Napoles");
		lblNewLabel_3_2_1_1_1_1_1.setBounds(580, 637, 230, 23);
		lblNewLabel_3_2_1_1_1_1_1.setIcon(new ImageIcon(infoitalia.class.getResource("/imagens/numero-7.png")));
		lblNewLabel_3_2_1_1_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		
		JTextPane txtpnCafDaManh_2_1_1_2 = new JTextPane();
		txtpnCafDaManh_2_1_1_2.setBounds(580, 671, 451, 90);
		txtpnCafDaManh_2_1_1_2.setText("Café da manhã. Os apartamentos estarão disponíveis até as 12h. Traslado compartilhado ao aeroporto ou estação de trem. (Opcional trem de alta velocidade para Roma). Fim de nossos serviços.");
		txtpnCafDaManh_2_1_1_2.setForeground(Color.GRAY);
		panel.setLayout(null);
		panel.add(txtpnEncantosDoSul_1);
		panel.add(separator_1);
		panel.add(txtpnPartidasDe_1);
		panel.add(lblNewLabel_2_3);
		panel.add(lblNewLabel_3);
		panel.add(txtpnChegadaAoAeroporto);
		panel.add(lblNewLabel_3_2_1);
		panel.add(lblNewLabel_3_2);
		panel.add(txtpnCafDaManh);
		panel.add(txtpnCafDaManh_2);
		panel.add(lblNewLabel_3_2_1_1_1_1);
		panel.add(txtpnCafDaManh_2_1_1_1);
		panel.add(lblNewLabel_3_2_1_1_1_1_1);
		panel.add(txtpnCafDaManh_2_1_1_2);
		panel.add(txtpnCafDaManh_2_1_1);
		panel.add(lblNewLabel_3_2_1_1_1);
		panel.add(lblNewLabel_3_2_1_1);
		panel.add(txtpnCafDaManh_2_1);
		panel.add(lblNewLabel_3_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(255, 255, 255));
		tabbedPane.addTab("SEGURO VIAGEM", null, panel_1, null);
		
		JTextPane textPane = new JTextPane();
		
		JTextPane txtpnEncantosDoSul_1_1 = new JTextPane();
		txtpnEncantosDoSul_1_1.setText("Sul da Itália + Roma - 2025 \r\n\r\n\r\n");
		txtpnEncantosDoSul_1_1.setForeground(Color.BLACK);
		txtpnEncantosDoSul_1_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		txtpnEncantosDoSul_1_1.setBackground(Color.WHITE);
		
		JTextPane txtpnPartidasDe_1_1 = new JTextPane();
		txtpnPartidasDe_1_1.setText("Partidas de 4 de outubro 2025 a 12 de outubro 2025\r\n\r\n\r\n");
		txtpnPartidasDe_1_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		txtpnPartidasDe_1_1.setBackground(new Color(53, 189, 255));
		
		JSeparator separator_1_1 = new JSeparator();
		
		JLabel lblNewLabel_3_4 = new JLabel("O Que é Seguro Viagem?");
		lblNewLabel_3_4.setIcon(new ImageIcon(infoitalia.class.getResource("/imagens/seguro.png")));
		lblNewLabel_3_4.setToolTipText("DATA:");
		lblNewLabel_3_4.setFont(new Font("Tahoma", Font.BOLD, 12));
		
		JTextPane txtpnOSeguroViagem = new JTextPane();
		txtpnOSeguroViagem.setText("O Seguro Viagem oferece um conjunto de coberturas para auxiliar o passageiro durante sua viagem em caso de urgência e emergência, com questões relacionadas a por exemplo: problemas de saúde, perda/dano de bagagem, e qualquer outro evento coberto.​ Em alguns países o Seguro Viagem é obrigatório. Garanta já o seu!");
		txtpnOSeguroViagem.setForeground(Color.GRAY);
		
		JLabel lblNewLabel_3_4_1 = new JLabel("O Que Oferece?");
		lblNewLabel_3_4_1.setIcon(new ImageIcon(infoitalia.class.getResource("/imagens/seguro.png")));
		lblNewLabel_3_4_1.setToolTipText("DATA:");
		lblNewLabel_3_4_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		
		JLabel lblNewLabel_3_5 = new JLabel("Atendimento 24 Horas");
		lblNewLabel_3_5.setIcon(new ImageIcon(infoitalia.class.getResource("/imagens/numero-1.png")));
		lblNewLabel_3_5.setToolTipText("DATA:");
		lblNewLabel_3_5.setFont(new Font("Tahoma", Font.BOLD, 12));
		
		JLabel lblNewLabel_3_5_1 = new JLabel("Assistência Médica e Odontológica");
		lblNewLabel_3_5_1.setIcon(new ImageIcon(infoitalia.class.getResource("/imagens/numero-2 (1).png")));
		lblNewLabel_3_5_1.setToolTipText("DATA:");
		lblNewLabel_3_5_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		
		JTextPane txtpnLigueGratuitamenteDurante = new JTextPane();
		txtpnLigueGratuitamenteDurante.setText("Ligue gratuitamente durante a sua viagem a qualquer momento.");
		txtpnLigueGratuitamenteDurante.setForeground(Color.GRAY);
		
		JTextPane txtpnAtendimentoEmCaso = new JTextPane();
		txtpnAtendimentoEmCaso.setText("Atendimento em caso de urgência/emergência.");
		txtpnAtendimentoEmCaso.setForeground(Color.GRAY);
		
		JLabel lblNewLabel_3_5_1_1 = new JLabel("Teleassistência Médica");
		lblNewLabel_3_5_1_1.setIcon(new ImageIcon(infoitalia.class.getResource("/imagens/numero-3.png")));
		lblNewLabel_3_5_1_1.setToolTipText("DATA:");
		lblNewLabel_3_5_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		
		JTextPane txtpnFaaUmTele = new JTextPane();
		txtpnFaaUmTele.setText("Faça um tele atendimento sem esperar ou sair de onde você está. Inclui prescrições.");
		txtpnFaaUmTele.setForeground(Color.GRAY);
		
		JLabel lblNewLabel_3_5_1_1_1 = new JLabel("Assistência Anti Perda de Bagagem");
		lblNewLabel_3_5_1_1_1.setIcon(new ImageIcon(infoitalia.class.getResource("/imagens/numero-4 (1).png")));
		lblNewLabel_3_5_1_1_1.setToolTipText("DATA:");
		lblNewLabel_3_5_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		
		JTextPane txtpnAssistnciaEReembolso = new JTextPane();
		txtpnAssistnciaEReembolso.setText("Assistência e reembolso por extravio ou perda de bagagens.");
		txtpnAssistnciaEReembolso.setForeground(Color.GRAY);
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel_1.createSequentialGroup()
							.addGap(393)
							.addGroup(gl_panel_1.createParallelGroup(Alignment.TRAILING)
								.addComponent(txtpnEncantosDoSul_1_1, GroupLayout.PREFERRED_SIZE, 335, GroupLayout.PREFERRED_SIZE)
								.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
									.addComponent(lblNewLabel_3_5_1_1, GroupLayout.PREFERRED_SIZE, 251, GroupLayout.PREFERRED_SIZE)
									.addComponent(separator_1_1, GroupLayout.PREFERRED_SIZE, 358, GroupLayout.PREFERRED_SIZE)))
							.addGap(2997)
							.addComponent(textPane, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel_1.createSequentialGroup()
							.addGap(416)
							.addComponent(txtpnPartidasDe_1_1, GroupLayout.PREFERRED_SIZE, 310, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel_1.createSequentialGroup()
							.addContainerGap()
							.addComponent(txtpnLigueGratuitamenteDurante, GroupLayout.PREFERRED_SIZE, 371, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(txtpnFaaUmTele, GroupLayout.PREFERRED_SIZE, 371, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel_1.createSequentialGroup()
							.addContainerGap()
							.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_panel_1.createSequentialGroup()
									.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING, false)
										.addComponent(lblNewLabel_3_5, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(lblNewLabel_3_4_1, GroupLayout.DEFAULT_SIZE, 196, Short.MAX_VALUE)
										.addComponent(txtpnAtendimentoEmCaso, GroupLayout.PREFERRED_SIZE, 371, GroupLayout.PREFERRED_SIZE))
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addComponent(txtpnAssistnciaEReembolso, GroupLayout.PREFERRED_SIZE, 371, GroupLayout.PREFERRED_SIZE))
								.addGroup(gl_panel_1.createSequentialGroup()
									.addComponent(lblNewLabel_3_5_1, GroupLayout.PREFERRED_SIZE, 251, GroupLayout.PREFERRED_SIZE)
									.addGap(130)
									.addComponent(lblNewLabel_3_5_1_1_1, GroupLayout.PREFERRED_SIZE, 251, GroupLayout.PREFERRED_SIZE))))
						.addGroup(gl_panel_1.createSequentialGroup()
							.addContainerGap()
							.addComponent(txtpnOSeguroViagem, GroupLayout.PREFERRED_SIZE, 371, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel_1.createSequentialGroup()
							.addContainerGap()
							.addComponent(lblNewLabel_3_4, GroupLayout.PREFERRED_SIZE, 196, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(3726, Short.MAX_VALUE))
		);
		gl_panel_1.setVerticalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel_1.createSequentialGroup()
							.addGap(5)
							.addComponent(textPane, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel_1.createSequentialGroup()
							.addGap(22)
							.addComponent(txtpnEncantosDoSul_1_1, GroupLayout.PREFERRED_SIZE, 33, GroupLayout.PREFERRED_SIZE)))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(separator_1_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(txtpnPartidasDe_1_1, GroupLayout.PREFERRED_SIZE, 26, GroupLayout.PREFERRED_SIZE)
					.addGap(26)
					.addComponent(lblNewLabel_3_4, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(txtpnOSeguroViagem, GroupLayout.PREFERRED_SIZE, 103, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(lblNewLabel_3_4_1, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_3_5, GroupLayout.PREFERRED_SIZE, 16, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_3_5_1_1, GroupLayout.PREFERRED_SIZE, 16, GroupLayout.PREFERRED_SIZE))
					.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel_1.createSequentialGroup()
							.addGap(13)
							.addComponent(txtpnLigueGratuitamenteDurante, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addGap(9)
							.addComponent(lblNewLabel_3_5_1, GroupLayout.PREFERRED_SIZE, 16, GroupLayout.PREFERRED_SIZE)
							.addGap(3)
							.addComponent(txtpnAtendimentoEmCaso, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel_1.createSequentialGroup()
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(txtpnFaaUmTele, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addGap(2)
							.addComponent(lblNewLabel_3_5_1_1_1, GroupLayout.PREFERRED_SIZE, 16, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(txtpnAssistnciaEReembolso, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(920, Short.MAX_VALUE))
		);
		panel_1.setLayout(gl_panel_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(255, 255, 255));
		tabbedPane.addTab("SERVIÇOS INCLUSOS", null, panel_2, null);
		
		JTextPane txtpnNoites = new JTextPane();
		txtpnNoites.setFont(new Font("Tahoma", Font.BOLD, 12));
		txtpnNoites.setText("· 7 noites de hospedagem com café da manhã.\r\n\r\n\r\n");
		
		JTextPane txtpnEncantosDoSul = new JTextPane();
		txtpnEncantosDoSul.setForeground(new Color(0, 0, 0));
		txtpnEncantosDoSul.setBackground(new Color(255, 255, 255));
		txtpnEncantosDoSul.setText("Sul da Itália + Roma - 2025 \r\n\r\n\r\n");
		txtpnEncantosDoSul.setFont(new Font("Tahoma", Font.BOLD, 20));
		
		JSeparator separator = new JSeparator();
		
		JTextPane txtpnPartidasDe = new JTextPane();
		txtpnPartidasDe.setBackground(new Color(53, 189, 255));
		txtpnPartidasDe.setText("Partidas de 4 de outubro 2025 a 12 de outubro 2025\r\n\r\n\r\n");
		txtpnPartidasDe.setFont(new Font("Tahoma", Font.PLAIN, 12));
		
		JTextPane txtpnTrasladosDe = new JTextPane();
		txtpnTrasladosDe.setText("· Traslados de chegada e saída (aeroporto ou estação de trem, compartilhados).\r\n\r\n");
		txtpnTrasladosDe.setFont(new Font("Tahoma", Font.PLAIN, 12));
		
		JTextPane txtpnEntradasNas = new JTextPane();
		txtpnEntradasNas.setText("· Entradas nas Grutas de Pertosa com passeio de barco.\r\n\r\n");
		txtpnEntradasNas.setFont(new Font("Tahoma", Font.BOLD, 12));
		
		JTextPane txtpnEntradasNas_1 = new JTextPane();
		txtpnEntradasNas_1.setText("· Entradas nos monumentos: Amalfi - Claustro, Pompéia - Ruínas, Paestum - Zona Arqueológica, Nápoles - Capela de São Severo.\r\n\r\n");
		txtpnEntradasNas_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		
		JTextPane txtpnEntradasNas_2 = new JTextPane();
		txtpnEntradasNas_2.setText("· Guia acompanhante em PORTUGUÊS! Durante todo o roteiro\r\n\r\n");
		txtpnEntradasNas_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		
		JTextPane txtpnEntradasNas_3 = new JTextPane();
		txtpnEntradasNas_3.setText("· Visitas panorâmicas com guia acompanhante (exceto em Roma, Pompéia, Nápoles, Paestum).\r\n\r\n");
		txtpnEntradasNas_3.setFont(new Font("Tahoma", Font.BOLD, 12));
		
		JTextPane txtpnEntradasNas_4 = new JTextPane();
		txtpnEntradasNas_4.setText("· Guias locais em Roma");
		txtpnEntradasNas_4.setFont(new Font("Tahoma", Font.BOLD, 12));
		
		JTextPane txtpnexceto = new JTextPane();
		txtpnexceto.setText("(exceto 1º, 2º e último dia). Atenção: com menos de 7 participantes, a viagem poderá ser realizada sem guia.");
		txtpnexceto.setFont(new Font("Tahoma", Font.PLAIN, 12));
		
		JTextPane txtpnEntradasNas_4_1 = new JTextPane();
		txtpnEntradasNas_4_1.setText("· Excursão a Capri com ferry público a Capri ida e volta (atenção em caso de cancelamento da excursão a Capri por motivos meteorológicos, não se realizará nenhum reembolso).");
		txtpnEntradasNas_4_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(infoitalia.class.getResource("/imagens/photo-1523906834658-6e24ef2386f9 (1).jpg")));
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(infoitalia.class.getResource("/imagens/istockphoto-539115110-612x612 (2).jpg")));
		
		JLabel lblNewLabel_1_1 = new JLabel("");
		lblNewLabel_1_1.setIcon(new ImageIcon(infoitalia.class.getResource("/imagens/leaning-tower-sunny-day-pisa-italy (1).jpg")));
		
		JLabel lblNewLabel_2 = new JLabel("Passagem Aéria Econômica");
		lblNewLabel_2.setIcon(new ImageIcon(infoitalia.class.getResource("/imagens/aviao (1).png")));
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2.setBackground(Color.WHITE);
		
		JLabel lblNewLabel_2_1_1 = new JLabel("Passagens aéreas de ida e volta em classe econômica.");
		lblNewLabel_2_1_1.setForeground(Color.GRAY);
		lblNewLabel_2_1_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		
		JLabel lblNewLabel_2_1 = new JLabel("Hospedagem + Café da Manhã");
		lblNewLabel_2_1.setIcon(new ImageIcon(infoitalia.class.getResource("/imagens/cama.png")));
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2_1.setBackground(Color.WHITE);
		
		JLabel lblNewLabel_2_1_1_1 = new JLabel("Com quarto duplo ou triplo.");
		lblNewLabel_2_1_1_1.setForeground(Color.GRAY);
		lblNewLabel_2_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		
		JLabel lblNewLabel_2_2 = new JLabel("Guia Acompanhante ");
		lblNewLabel_2_2.setIcon(new ImageIcon(infoitalia.class.getResource("/imagens/guia-turistico (1).png")));
		lblNewLabel_2_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2_2.setBackground(Color.WHITE);
		
		JLabel lblNewLabel_2_1_1_2 = new JLabel("Em Português! Durante todo o trajeto.");
		lblNewLabel_2_1_1_2.setForeground(Color.GRAY);
		lblNewLabel_2_1_1_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		
		JButton btnExploreItlia = new JButton("EXPLORE ITÁLIA");
		btnExploreItlia.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String url = "https://www.google.com/maps/place/It%C3%A1lia/@41.29085,12.71216,6z/data=!3m1!4b1!4m6!3m5!1s0x12d4fe82448dd203:0xe22cf55c24635e6f!8m2!3d41.87194!4d12.56738!16zL20vMDNyamo?entry=ttu&g_ep=EgoyMDI0MDkwOS4wIKXMDSoASAFQAw%3D%3D";
					if (Desktop.isDesktopSupported()) {
						Desktop desktop = Desktop.getDesktop();
						desktop.browse(new URI(url));
					} else {
						System.out.println("Desktop não suportado.");
					}
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		});
		
		JLabel lblNewLabel_2_2_1 = new JLabel("Transfer Local");
		lblNewLabel_2_2_1.setIcon(new ImageIcon(infoitalia.class.getResource("/imagens/carros.png")));
		lblNewLabel_2_2_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2_2_1.setBackground(Color.WHITE);
		
		JLabel lblNewLabel_2_1_1_2_1 = new JLabel("Inclui descolamento entre cidades.");
		lblNewLabel_2_1_1_2_1.setForeground(Color.GRAY);
		lblNewLabel_2_1_1_2_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		GroupLayout gl_panel_2 = new GroupLayout(panel_2);
		gl_panel_2.setHorizontalGroup(
			gl_panel_2.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_2.createSequentialGroup()
					.addGap(25)
					.addGroup(gl_panel_2.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel_2.createSequentialGroup()
							.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addGroup(gl_panel_2.createParallelGroup(Alignment.TRAILING, false)
								.addGroup(gl_panel_2.createSequentialGroup()
									.addGroup(gl_panel_2.createParallelGroup(Alignment.TRAILING)
										.addGroup(gl_panel_2.createSequentialGroup()
											.addGroup(gl_panel_2.createParallelGroup(Alignment.LEADING)
												.addComponent(txtpnEntradasNas_4_1, GroupLayout.PREFERRED_SIZE, 426, GroupLayout.PREFERRED_SIZE)
												.addComponent(txtpnEntradasNas_4, GroupLayout.PREFERRED_SIZE, 426, GroupLayout.PREFERRED_SIZE)
												.addComponent(txtpnEntradasNas_3, GroupLayout.PREFERRED_SIZE, 426, GroupLayout.PREFERRED_SIZE)
												.addComponent(txtpnexceto, GroupLayout.PREFERRED_SIZE, 481, GroupLayout.PREFERRED_SIZE)
												.addComponent(txtpnEntradasNas_2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
												.addComponent(txtpnEntradasNas_1, GroupLayout.PREFERRED_SIZE, 426, GroupLayout.PREFERRED_SIZE)
												.addComponent(txtpnEntradasNas, GroupLayout.PREFERRED_SIZE, 426, GroupLayout.PREFERRED_SIZE)
												.addComponent(txtpnTrasladosDe, GroupLayout.PREFERRED_SIZE, 481, GroupLayout.PREFERRED_SIZE)
												.addComponent(txtpnNoites, GroupLayout.PREFERRED_SIZE, 426, GroupLayout.PREFERRED_SIZE))
											.addGap(18))
										.addGroup(gl_panel_2.createSequentialGroup()
											.addGroup(gl_panel_2.createParallelGroup(Alignment.LEADING)
												.addComponent(lblNewLabel_2, GroupLayout.PREFERRED_SIZE, 240, GroupLayout.PREFERRED_SIZE)
												.addComponent(lblNewLabel_2_1_1, GroupLayout.PREFERRED_SIZE, 319, GroupLayout.PREFERRED_SIZE)
												.addComponent(lblNewLabel_2_2, GroupLayout.PREFERRED_SIZE, 263, GroupLayout.PREFERRED_SIZE)
												.addComponent(lblNewLabel_2_1_1_2, GroupLayout.PREFERRED_SIZE, 237, GroupLayout.PREFERRED_SIZE))
											.addGap(190)))
									.addPreferredGap(ComponentPlacement.RELATED))
								.addGroup(gl_panel_2.createSequentialGroup()
									.addComponent(btnExploreItlia, GroupLayout.PREFERRED_SIZE, 199, GroupLayout.PREFERRED_SIZE)
									.addGap(214)))
							.addGroup(gl_panel_2.createParallelGroup(Alignment.LEADING)
								.addComponent(lblNewLabel_2_1_1_1, GroupLayout.PREFERRED_SIZE, 319, GroupLayout.PREFERRED_SIZE)
								.addComponent(lblNewLabel_2_1, GroupLayout.PREFERRED_SIZE, 240, GroupLayout.PREFERRED_SIZE)
								.addComponent(lblNewLabel_2_2_1, GroupLayout.PREFERRED_SIZE, 263, GroupLayout.PREFERRED_SIZE)
								.addGroup(gl_panel_2.createSequentialGroup()
									.addGroup(gl_panel_2.createParallelGroup(Alignment.LEADING)
										.addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 300, GroupLayout.PREFERRED_SIZE)
										.addComponent(lblNewLabel_1_1, GroupLayout.PREFERRED_SIZE, 300, GroupLayout.PREFERRED_SIZE))
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(lblNewLabel))
								.addComponent(lblNewLabel_2_1_1_2_1, GroupLayout.PREFERRED_SIZE, 237, GroupLayout.PREFERRED_SIZE)))
						.addGroup(gl_panel_2.createSequentialGroup()
							.addGap(472)
							.addComponent(txtpnEncantosDoSul, GroupLayout.PREFERRED_SIZE, 596, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel_2.createSequentialGroup()
							.addGap(436)
							.addComponent(separator, GroupLayout.PREFERRED_SIZE, 358, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel_2.createSequentialGroup()
							.addGap(474)
							.addComponent(txtpnPartidasDe, GroupLayout.PREFERRED_SIZE, 310, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(5942, Short.MAX_VALUE))
		);
		gl_panel_2.setVerticalGroup(
			gl_panel_2.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_2.createSequentialGroup()
					.addContainerGap()
					.addComponent(txtpnEncantosDoSul, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(separator, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(txtpnPartidasDe, GroupLayout.PREFERRED_SIZE, 26, GroupLayout.PREFERRED_SIZE)
					.addGap(128)
					.addGroup(gl_panel_2.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_2, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_2_1, GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_panel_2.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel_2.createSequentialGroup()
							.addComponent(lblNewLabel_2_1_1, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(lblNewLabel_2_2, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)
							.addGap(2)
							.addComponent(lblNewLabel_2_1_1_2, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(txtpnNoites, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(txtpnTrasladosDe, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(txtpnEntradasNas, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(txtpnEntradasNas_1, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(txtpnEntradasNas_2, GroupLayout.PREFERRED_SIZE, 23, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(txtpnexceto, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(txtpnEntradasNas_3, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(txtpnEntradasNas_4, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(txtpnEntradasNas_4_1, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE)
							.addGap(62)
							.addComponent(btnExploreItlia))
						.addGroup(gl_panel_2.createSequentialGroup()
							.addComponent(lblNewLabel_2_1_1_1, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(lblNewLabel_2_2_1, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(lblNewLabel_2_1_1_2_1, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)
							.addGap(41)
							.addGroup(gl_panel_2.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_panel_2.createSequentialGroup()
									.addGap(28)
									.addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 250, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addComponent(lblNewLabel_1_1, GroupLayout.PREFERRED_SIZE, 236, GroupLayout.PREFERRED_SIZE))
								.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 557, GroupLayout.PREFERRED_SIZE))))
					.addGap(356))
		);
		gl_panel_2.linkSize(SwingConstants.HORIZONTAL, new Component[] {lblNewLabel, lblNewLabel_1, lblNewLabel_1_1});
		panel_2.setLayout(gl_panel_2);
	}
}
