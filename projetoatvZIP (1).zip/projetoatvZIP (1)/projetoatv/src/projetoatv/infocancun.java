package projetoatv;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTabbedPane;
import java.awt.BorderLayout;
import javax.swing.JPanel;
import java.awt.Toolkit;
import java.awt.Color;
import java.awt.Desktop;

import javax.swing.JTextPane;
import java.awt.Font;
import javax.swing.JSeparator;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.net.URI;
import java.awt.event.ActionEvent;

public class infocancun {

	private JFrame frmPacoteCancn;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					infocancun window = new infocancun();
					window.frmPacoteCancn.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public infocancun() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmPacoteCancn = new JFrame();
		frmPacoteCancn.setIconImage(Toolkit.getDefaultToolkit().getImage(infocancun.class.getResource("/imagens/mexico.png")));
		frmPacoteCancn.setTitle("PACOTE CANCÚN");
		frmPacoteCancn.setBounds(100, 100, 1358, 788);
		frmPacoteCancn.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmPacoteCancn.getContentPane().setLayout(new BorderLayout(0, 0));
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		frmPacoteCancn.getContentPane().add(tabbedPane);
		
		JPanel panel_3 = new JPanel();
		tabbedPane.addTab("SERVIÇOS  INCLUSOS", null, panel_3, null);
		panel_3.setLayout(null);
		
		JPanel panel_4 = new JPanel();
		panel_4.setLayout(null);
		panel_4.setBackground(Color.WHITE);
		panel_4.setBounds(-48, 11, 1313, 721);
		panel_3.add(panel_4);
		
		JTextPane txtpnEgito_3 = new JTextPane();
		txtpnEgito_3.setText("CANCÚN - 2024");
		txtpnEgito_3.setForeground(Color.BLACK);
		txtpnEgito_3.setFont(new Font("Tahoma", Font.BOLD, 20));
		txtpnEgito_3.setBackground(Color.WHITE);
		txtpnEgito_3.setBounds(720, 11, 413, 31);
		panel_4.add(txtpnEgito_3);
		
		JSeparator separator_3 = new JSeparator();
		separator_3.setBounds(604, 53, 358, 2);
		panel_4.add(separator_3);
		
		JTextPane txtpnPartidasDe_1_3 = new JTextPane();
		txtpnPartidasDe_1_3.setText("Partidas de 27 de setembro 2024 a 20 de dezembro 2024");
		txtpnPartidasDe_1_3.setFont(new Font("Tahoma", Font.PLAIN, 12));
		txtpnPartidasDe_1_3.setBackground(new Color(53, 189, 255));
		txtpnPartidasDe_1_3.setBounds(624, 66, 338, 26);
		panel_4.add(txtpnPartidasDe_1_3);
		
		JLabel lblNewLabel_2 = new JLabel("Passagem Aéria Econômica");
		lblNewLabel_2.setIcon(new ImageIcon(infocancun.class.getResource("/imagens/aviao (1).png")));
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2.setBackground(Color.WHITE);
		lblNewLabel_2.setBounds(54, 168, 240, 27);
		panel_4.add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel("Hospedagem + Café da Manhã");
		lblNewLabel_2_1.setIcon(new ImageIcon(infocancun.class.getResource("/imagens/cama.png")));
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2_1.setBackground(Color.WHITE);
		lblNewLabel_2_1.setBounds(386, 168, 240, 27);
		panel_4.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_2_1_1 = new JLabel("Passagens aéreas de ida e volta em classe econômica.");
		lblNewLabel_2_1_1.setForeground(Color.GRAY);
		lblNewLabel_2_1_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_2_1_1.setBounds(54, 193, 319, 27);
		panel_4.add(lblNewLabel_2_1_1);
		
		JLabel lblNewLabel_2_1_1_1 = new JLabel("Com quarto duplo ou triplo.");
		lblNewLabel_2_1_1_1.setForeground(Color.GRAY);
		lblNewLabel_2_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_2_1_1_1.setBounds(396, 193, 319, 27);
		panel_4.add(lblNewLabel_2_1_1_1);
		
		JLabel lblNewLabel_2_2 = new JLabel("Guia Acompanhante ");
		lblNewLabel_2_2.setIcon(new ImageIcon(infocancun.class.getResource("/imagens/guia-turistico (1).png")));
		lblNewLabel_2_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2_2.setBackground(Color.WHITE);
		lblNewLabel_2_2.setBounds(54, 231, 263, 27);
		panel_4.add(lblNewLabel_2_2);
		
		JLabel lblNewLabel_2_1_1_2 = new JLabel("Durante todo o trajeto.");
		lblNewLabel_2_1_1_2.setForeground(Color.GRAY);
		lblNewLabel_2_1_1_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_2_1_1_2.setBounds(57, 265, 237, 27);
		panel_4.add(lblNewLabel_2_1_1_2);
		
		JLabel lblNewLabel_2_2_1 = new JLabel("Transfer Local");
		lblNewLabel_2_2_1.setIcon(new ImageIcon(infocancun.class.getResource("/imagens/carros.png")));
		lblNewLabel_2_2_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2_2_1.setBackground(Color.WHITE);
		lblNewLabel_2_2_1.setBounds(384, 231, 263, 27);
		panel_4.add(lblNewLabel_2_2_1);
		
		JLabel lblNewLabel_2_1_1_2_1 = new JLabel("Inclui descolamento na chegada e na saída");
		lblNewLabel_2_1_1_2_1.setForeground(Color.GRAY);
		lblNewLabel_2_1_1_2_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_2_1_1_2_1.setBounds(389, 265, 237, 27);
		panel_4.add(lblNewLabel_2_1_1_2_1);
		
		JTextPane txtpnNoitesDe = new JTextPane();
		txtpnNoitesDe.setText("4 noites de hospedagem no hotel selecionado em Cancún;");
		txtpnNoitesDe.setFont(new Font("Tahoma", Font.BOLD, 12));
		txtpnNoitesDe.setBounds(54, 318, 426, 21);
		panel_4.add(txtpnNoitesDe);
		
		JTextPane txtpnNoites_1_1 = new JTextPane();
		txtpnNoites_1_1.setText("Sistema de alimentação, de acordo com o hotel selecionado;");
		txtpnNoites_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		txtpnNoites_1_1.setBounds(54, 368, 426, 36);
		panel_4.add(txtpnNoites_1_1);
		
		JTextPane txtpnNoites_2 = new JTextPane();
		txtpnNoites_2.setText("Todos os traslados são feitos em carro compartilhado ");
		txtpnNoites_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		txtpnNoites_2.setBounds(54, 343, 467, 31);
		panel_4.add(txtpnNoites_2);
		
		JTextPane txtpnNoites_2_1 = new JTextPane();
		txtpnNoites_2_1.setText("Guia acompanhante em PORTUGUÊS! Durante todo o roteiro");
		txtpnNoites_2_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		txtpnNoites_2_1.setBounds(54, 398, 467, 21);
		panel_4.add(txtpnNoites_2_1);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(infocancun.class.getResource("/imagens/images (3).jpg")));
		lblNewLabel_1.setBounds(657, 373, 300, 202);
		panel_4.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("");
		lblNewLabel_1_1.setIcon(new ImageIcon(infocancun.class.getResource("/imagens/images (2).jpg")));
		lblNewLabel_1_1.setBounds(657, 150, 300, 202);
		panel_4.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(infocancun.class.getResource("/imagens/410657246 (1).jpg")));
		lblNewLabel.setBounds(980, 138, 300, 430);
		panel_4.add(lblNewLabel);
		
		JButton btnExploreCancn = new JButton("EXPLORE CANCÚN");
		btnExploreCancn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String url = "https://www.google.com/maps/place/Canc%C3%BAn,+Quintana+Roo,+M%C3%A9xico/data=!4m2!3m1!1s0x8f4c2b05aef653db:0xce32b73c625fcd8a?sa=X&ved=1t:242&ictx=111";
					if (Desktop.isDesktopSupported()) {
						Desktop desktop = Desktop.getDesktop();
						desktop.browse(new URI(url));
					} else {
						System.out.println("Desktop não suportado.");
					}
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		});
		btnExploreCancn.setBounds(164, 552, 199, 23);
		panel_4.add(btnExploreCancn);
		
		JPanel panel_2 = new JPanel();
		tabbedPane.addTab("SERVIÇOS NÃO INCLUSOS", null, panel_2, null);
		panel_2.setLayout(null);
		
		JPanel panel_1_1 = new JPanel();
		panel_1_1.setLayout(null);
		panel_1_1.setBackground(Color.WHITE);
		panel_1_1.setBounds(0, 0, 1290, 721);
		panel_2.add(panel_1_1);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setBounds(479, 53, 358, 2);
		panel_1_1.add(separator_2);
		
		JTextPane txtpnEgito_3_1 = new JTextPane();
		txtpnEgito_3_1.setText("CANCÚN - 2024");
		txtpnEgito_3_1.setForeground(Color.BLACK);
		txtpnEgito_3_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		txtpnEgito_3_1.setBackground(Color.WHITE);
		txtpnEgito_3_1.setBounds(584, 11, 413, 31);
		panel_1_1.add(txtpnEgito_3_1);
		
		JLabel lblNewLabel_3_3 = new JLabel("Taxas de turismo de entrada/saída cobradas localmente;");
		lblNewLabel_3_3.setIcon(new ImageIcon(infocancun.class.getResource("/imagens/numero-1.png")));
		lblNewLabel_3_3.setToolTipText("DATA:");
		lblNewLabel_3_3.setForeground(Color.GRAY);
		lblNewLabel_3_3.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_3_3.setBounds(10, 155, 346, 16);
		panel_1_1.add(lblNewLabel_3_3);
		
		JLabel lblNewLabel_3_3_1 = new JLabel("Passeios Opcionais");
		lblNewLabel_3_3_1.setIcon(new ImageIcon(infocancun.class.getResource("/imagens/numero-2 (1).png")));
		lblNewLabel_3_3_1.setToolTipText("DATA:");
		lblNewLabel_3_3_1.setForeground(Color.GRAY);
		lblNewLabel_3_3_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_3_3_1.setBounds(10, 189, 346, 16);
		panel_1_1.add(lblNewLabel_3_3_1);
		
		JLabel lblNewLabel_3_3_1_1 = new JLabel("Gorjetas a guias, motoristas e garçons;");
		lblNewLabel_3_3_1_1.setIcon(new ImageIcon(infocancun.class.getResource("/imagens/numero-5.png")));
		lblNewLabel_3_3_1_1.setToolTipText("DATA:");
		lblNewLabel_3_3_1_1.setForeground(Color.GRAY);
		lblNewLabel_3_3_1_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_3_3_1_1.setBounds(446, 189, 271, 16);
		panel_1_1.add(lblNewLabel_3_3_1_1);
		
		JLabel lblNewLabel_3_3_1_1_1 = new JLabel("Refeições e bebidas não mencionadas como incluídas;");
		lblNewLabel_3_3_1_1_1.setIcon(new ImageIcon(infocancun.class.getResource("/imagens/numero-4 (1).png")));
		lblNewLabel_3_3_1_1_1.setToolTipText("DATA:");
		lblNewLabel_3_3_1_1_1.setForeground(Color.GRAY);
		lblNewLabel_3_3_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_3_3_1_1_1.setBounds(446, 155, 323, 16);
		panel_1_1.add(lblNewLabel_3_3_1_1_1);
		
		JLabel lblNewLabel_3_3_1_1_1_3 = new JLabel("Despesas de caráter pessoal como:");
		lblNewLabel_3_3_1_1_1_3.setIcon(new ImageIcon(infocancun.class.getResource("/imagens/numero-3.png")));
		lblNewLabel_3_3_1_1_1_3.setToolTipText("DATA:");
		lblNewLabel_3_3_1_1_1_3.setForeground(Color.GRAY);
		lblNewLabel_3_3_1_1_1_3.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_3_3_1_1_1_3.setBounds(10, 216, 323, 36);
		panel_1_1.add(lblNewLabel_3_3_1_1_1_3);
		
		JLabel lblNewLabel_3_3_1_1_1_1 = new JLabel("Qualquer item não mencionado como incluído.");
		lblNewLabel_3_3_1_1_1_1.setIcon(new ImageIcon(infocancun.class.getResource("/imagens/numero-6.png")));
		lblNewLabel_3_3_1_1_1_1.setToolTipText("DATA:");
		lblNewLabel_3_3_1_1_1_1.setForeground(Color.GRAY);
		lblNewLabel_3_3_1_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_3_3_1_1_1_1.setBounds(446, 226, 320, 16);
		panel_1_1.add(lblNewLabel_3_3_1_1_1_1);
		
		JLabel lblNewLabel_3_3_1_2 = new JLabel(" telefonemas, lavanderia, utilização de frigobar e excesso de bagagem\r\n");
		lblNewLabel_3_3_1_2.setToolTipText("DATA:");
		lblNewLabel_3_3_1_2.setForeground(Color.GRAY);
		lblNewLabel_3_3_1_2.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblNewLabel_3_3_1_2.setBounds(10, 245, 381, 31);
		panel_1_1.add(lblNewLabel_3_3_1_2);
		
		JTextPane txtpnPartidasDe_1_3_1 = new JTextPane();
		txtpnPartidasDe_1_3_1.setText("Partidas de 27 de setembro 2024 a 20 de dezembro 2024");
		txtpnPartidasDe_1_3_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		txtpnPartidasDe_1_3_1.setBackground(new Color(53, 189, 255));
		txtpnPartidasDe_1_3_1.setBounds(489, 63, 338, 26);
		panel_1_1.add(txtpnPartidasDe_1_3_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(255, 255, 255));
		tabbedPane.addTab("ROTEIRO", null, panel_1, null);
		panel_1.setLayout(null);
		
		JPanel panel_2_1 = new JPanel();
		panel_2_1.setLayout(null);
		panel_2_1.setBackground(Color.WHITE);
		panel_2_1.setBounds(0, 0, 1290, 721);
		panel_1.add(panel_2_1);
		
		JLabel lblNewLabel_3 = new JLabel("Cancún");
		lblNewLabel_3.setIcon(new ImageIcon(infocancun.class.getResource("/imagens/numero-1.png")));
		lblNewLabel_3.setToolTipText("DATA:");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3.setBounds(25, 127, 94, 16);
		panel_2_1.add(lblNewLabel_3);
		
		JTextPane txtpnChegadaAoAeroporto_1 = new JTextPane();
		txtpnChegadaAoAeroporto_1.setText("Apresentação no aeroporto para embarque com destino a Cancun. ( Passagem aérea não incluída, consulte nossas melhores tarifas ). Desembarque e traslado ao hotel. Os apartamentos estarão disponíveis a partir das 15h. Hospedagem.");
		txtpnChegadaAoAeroporto_1.setForeground(Color.GRAY);
		txtpnChegadaAoAeroporto_1.setBounds(25, 153, 310, 95);
		panel_2_1.add(txtpnChegadaAoAeroporto_1);
		
		JLabel lblNewLabel_3_2 = new JLabel("Cancún");
		lblNewLabel_3_2.setIcon(new ImageIcon(infocancun.class.getResource("/imagens/numero-2 (1).png")));
		lblNewLabel_3_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3_2.setBounds(25, 259, 136, 23);
		panel_2_1.add(lblNewLabel_3_2);
		
		JTextPane txtpnCafDaManh_1 = new JTextPane();
		txtpnCafDaManh_1.setText("Dia livre. Sugerimos o passeio Chichen-Itzá (Opcional). Hospedagem");
		txtpnCafDaManh_1.setForeground(Color.GRAY);
		txtpnCafDaManh_1.setBounds(25, 283, 371, 100);
		panel_2_1.add(txtpnCafDaManh_1);
		
		JLabel lblNewLabel_3_2_1 = new JLabel("Cancún");
		lblNewLabel_3_2_1.setIcon(new ImageIcon(infocancun.class.getResource("/imagens/numero-3.png")));
		lblNewLabel_3_2_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3_2_1.setBounds(25, 401, 195, 23);
		panel_2_1.add(lblNewLabel_3_2_1);
		
		JTextPane txtpnCafDaManh_2 = new JTextPane();
		txtpnCafDaManh_2.setText("Dia livre. Sugerimos o passeio Xel-Ha (opcional). Hospedagem.");
		txtpnCafDaManh_2.setForeground(Color.GRAY);
		txtpnCafDaManh_2.setBounds(25, 435, 371, 90);
		panel_2_1.add(txtpnCafDaManh_2);
		
		JLabel lblNewLabel_3_1 = new JLabel("Cancún");
		lblNewLabel_3_1.setIcon(new ImageIcon(infocancun.class.getResource("/imagens/numero-4 (1).png")));
		lblNewLabel_3_1.setToolTipText("DATA:");
		lblNewLabel_3_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3_1.setBounds(503, 127, 173, 16);
		panel_2_1.add(lblNewLabel_3_1);
		
		JTextPane txtpnChegadaAoAeroporto_1_1 = new JTextPane();
		txtpnChegadaAoAeroporto_1_1.setText("Dia livre. Sugerimos o passeio para Xcaret (opcional). Hospedagem.");
		txtpnChegadaAoAeroporto_1_1.setForeground(Color.GRAY);
		txtpnChegadaAoAeroporto_1_1.setBounds(503, 153, 397, 100);
		panel_2_1.add(txtpnChegadaAoAeroporto_1_1);
		
		JLabel lblNewLabel_3_2_2 = new JLabel("Cancún");
		lblNewLabel_3_2_2.setIcon(new ImageIcon(infocancun.class.getResource("/imagens/numero-5.png")));
		lblNewLabel_3_2_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3_2_2.setBounds(503, 259, 243, 23);
		panel_2_1.add(lblNewLabel_3_2_2);
		
		JTextPane txtpnCafDaManh_1_1 = new JTextPane();
		txtpnCafDaManh_1_1.setText("Dispomos dos apartamentos até as 12h. Em horário apropriado, traslado ao aeroporto para embarque, Fim dos nossos serviços.");
		txtpnCafDaManh_1_1.setForeground(Color.GRAY);
		txtpnCafDaManh_1_1.setBounds(503, 283, 371, 100);
		panel_2_1.add(txtpnCafDaManh_1_1);
		
		JTextPane txtpnPartidasDe_1_3_1_1 = new JTextPane();
		txtpnPartidasDe_1_3_1_1.setText("Partidas de 27 de setembro 2024 a 20 de dezembro 2024");
		txtpnPartidasDe_1_3_1_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		txtpnPartidasDe_1_3_1_1.setBackground(new Color(53, 189, 255));
		txtpnPartidasDe_1_3_1_1.setBounds(555, 63, 338, 26);
		panel_2_1.add(txtpnPartidasDe_1_3_1_1);
		
		JSeparator separator_2_1 = new JSeparator();
		separator_2_1.setBounds(545, 53, 358, 2);
		panel_2_1.add(separator_2_1);
		
		JTextPane txtpnEgito_3_1_1 = new JTextPane();
		txtpnEgito_3_1_1.setText("CANCÚN - 2024");
		txtpnEgito_3_1_1.setForeground(Color.BLACK);
		txtpnEgito_3_1_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		txtpnEgito_3_1_1.setBackground(Color.WHITE);
		txtpnEgito_3_1_1.setBounds(650, 11, 413, 31);
		panel_2_1.add(txtpnEgito_3_1_1);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		tabbedPane.addTab("SEGURO VIAGEM", null, panel, null);
		panel.setLayout(null);
		
		JLabel lblNewLabel_3_4 = new JLabel("O Que é Seguro Viagem?");
		lblNewLabel_3_4.setIcon(new ImageIcon(infocancun.class.getResource("/imagens/seguro.png")));
		lblNewLabel_3_4.setToolTipText("DATA:");
		lblNewLabel_3_4.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3_4.setBounds(10, 154, 196, 25);
		panel.add(lblNewLabel_3_4);
		
		JTextPane txtpnOSeguroViagem = new JTextPane();
		txtpnOSeguroViagem.setText("O Seguro Viagem oferece um conjunto de coberturas para auxiliar o passageiro durante sua viagem em caso de urgência e emergência, com questões relacionadas a por exemplo: problemas de saúde, perda/dano de bagagem, e qualquer outro evento coberto.​ Em alguns países o Seguro Viagem é obrigatório. Garanta já o seu!");
		txtpnOSeguroViagem.setForeground(Color.GRAY);
		txtpnOSeguroViagem.setBounds(10, 190, 371, 103);
		panel.add(txtpnOSeguroViagem);
		
		JLabel lblNewLabel_3_4_1 = new JLabel("O Que Oferece?");
		lblNewLabel_3_4_1.setIcon(new ImageIcon(infocancun.class.getResource("/imagens/seguro.png")));
		lblNewLabel_3_4_1.setToolTipText("DATA:");
		lblNewLabel_3_4_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3_4_1.setBounds(10, 299, 371, 25);
		panel.add(lblNewLabel_3_4_1);
		
		JLabel lblNewLabel_3_5 = new JLabel("Atendimento 24 Horas");
		lblNewLabel_3_5.setIcon(new ImageIcon(infocancun.class.getResource("/imagens/numero-1.png")));
		lblNewLabel_3_5.setToolTipText("DATA:");
		lblNewLabel_3_5.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3_5.setBounds(10, 335, 371, 16);
		panel.add(lblNewLabel_3_5);
		
		JTextPane txtpnLigueGratuitamenteDurante = new JTextPane();
		txtpnLigueGratuitamenteDurante.setText("Ligue gratuitamente durante a sua viagem a qualquer momento.");
		txtpnLigueGratuitamenteDurante.setForeground(Color.GRAY);
		txtpnLigueGratuitamenteDurante.setBounds(10, 364, 371, 20);
		panel.add(txtpnLigueGratuitamenteDurante);
		
		JLabel lblNewLabel_3_5_1 = new JLabel("Assistência Médica e Odontológica");
		lblNewLabel_3_5_1.setIcon(new ImageIcon(infocancun.class.getResource("/imagens/numero-2 (1).png")));
		lblNewLabel_3_5_1.setToolTipText("DATA:");
		lblNewLabel_3_5_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3_5_1.setBounds(10, 393, 251, 16);
		panel.add(lblNewLabel_3_5_1);
		
		JTextPane txtpnAtendimentoEmCaso = new JTextPane();
		txtpnAtendimentoEmCaso.setText("Atendimento em caso de urgência/emergência.");
		txtpnAtendimentoEmCaso.setForeground(Color.GRAY);
		txtpnAtendimentoEmCaso.setBounds(10, 412, 371, 20);
		panel.add(txtpnAtendimentoEmCaso);
		
		JLabel lblNewLabel_3_5_1_1 = new JLabel("Teleassistência Médica");
		lblNewLabel_3_5_1_1.setIcon(new ImageIcon(infocancun.class.getResource("/imagens/numero-3.png")));
		lblNewLabel_3_5_1_1.setToolTipText("DATA:");
		lblNewLabel_3_5_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3_5_1_1.setBounds(393, 335, 251, 16);
		panel.add(lblNewLabel_3_5_1_1);
		
		JTextPane txtpnFaaUmTele = new JTextPane();
		txtpnFaaUmTele.setText("Faça um tele atendimento sem esperar ou sair de onde você está. Inclui prescrições.");
		txtpnFaaUmTele.setForeground(Color.GRAY);
		txtpnFaaUmTele.setBounds(399, 357, 371, 34);
		panel.add(txtpnFaaUmTele);
		
		JLabel lblNewLabel_3_5_1_1_1 = new JLabel("Assistência Anti Perda de Bagagem");
		lblNewLabel_3_5_1_1_1.setIcon(new ImageIcon(infocancun.class.getResource("/imagens/numero-4 (1).png")));
		lblNewLabel_3_5_1_1_1.setToolTipText("DATA:");
		lblNewLabel_3_5_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3_5_1_1_1.setBounds(391, 393, 251, 16);
		panel.add(lblNewLabel_3_5_1_1_1);
		
		JTextPane txtpnAssistnciaEReembolso = new JTextPane();
		txtpnAssistnciaEReembolso.setText("Assistência e reembolso por extravio ou perda de bagagens.");
		txtpnAssistnciaEReembolso.setForeground(Color.GRAY);
		txtpnAssistnciaEReembolso.setBounds(391, 415, 371, 20);
		panel.add(txtpnAssistnciaEReembolso);
		
		JTextPane txtpnEgito_3_2 = new JTextPane();
		txtpnEgito_3_2.setText("CANCÚN - 2024");
		txtpnEgito_3_2.setForeground(Color.BLACK);
		txtpnEgito_3_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		txtpnEgito_3_2.setBackground(Color.WHITE);
		txtpnEgito_3_2.setBounds(636, 11, 413, 31);
		panel.add(txtpnEgito_3_2);
		
		JSeparator separator_3_1 = new JSeparator();
		separator_3_1.setBounds(520, 53, 358, 2);
		panel.add(separator_3_1);
		
		JTextPane txtpnPartidasDe_1_3_2 = new JTextPane();
		txtpnPartidasDe_1_3_2.setText("Partidas de 27 de setembro 2024 a 20 de dezembro 2024");
		txtpnPartidasDe_1_3_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		txtpnPartidasDe_1_3_2.setBackground(new Color(53, 189, 255));
		txtpnPartidasDe_1_3_2.setBounds(540, 66, 338, 26);
		panel.add(txtpnPartidasDe_1_3_2);
	}

}
