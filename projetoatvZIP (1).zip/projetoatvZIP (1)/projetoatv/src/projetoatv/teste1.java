package projetoatv;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTabbedPane;
import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JSeparator;
import javax.swing.JScrollPane;
import javax.swing.JPopupMenu;
import java.awt.Component;
import java.awt.Desktop;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.URI;

import javax.swing.JLayeredPane;
import javax.swing.JMenuBar;
import javax.swing.SwingConstants;
import javax.swing.JTextPane;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class teste1 {

    private JFrame frame;
    private JTextField textField;
    private JTextField textField_1;
    private JTextField textField_2;
    private JTextField textField_3;
    private JTextField textField_4;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    teste1 window = new teste1();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the application.
     */
    public teste1() {
        initialize();
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 3705, 1226);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(new BorderLayout(0, 0));
        
        JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
        frame.getContentPane().add(tabbedPane, BorderLayout.NORTH);
        
        JPanel panel_6 = new JPanel();
        panel_6.setBackground(new Color(255, 255, 255));
        
        // Criação do JScrollPane e adição do JPanel a ele
        JScrollPane scrollPane = new JScrollPane(panel_6);
        
        tabbedPane.addTab("PACOTES INTERNACIONAIS", new ImageIcon(teste1.class.getResource("/imagens/viajar-por.png")), scrollPane, null);
        
        JLabel lblNewLabel_3_2 = new JLabel("");
        lblNewLabel_3_2.setIcon(new ImageIcon(teste1.class.getResource("/imagens/WhatsApp Image 2024-09-06 at 22.40.24 (1) (1).jpeg")));
        
        JLabel lblNewLabel_3_2_1 = new JLabel("");
        lblNewLabel_3_2_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/WhatsApp Image 2024-09-06 at 22.53.36 (2) (1).jpeg")));
        
        JLabel lblNewLabel_3_2_1_1 = new JLabel("");
        lblNewLabel_3_2_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/WhatsApp Image 2024-09-07 at 00.16.37 (3) (1).jpeg")));
        
        JLabel lblNewLabel_3_2_1_1_1 = new JLabel("");
        lblNewLabel_3_2_1_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/WhatsApp Image 2024-09-06 at 23.02.05 (1).jpeg")));
        
        JButton btnNewButton = new JButton("");
        btnNewButton.setBackground(new Color(0, 128, 192));
        btnNewButton.setIcon(new ImageIcon(teste1.class.getResource("/imagens/simbolo-de-informacao.png")));
        
        JButton btnNewButton_1 = new JButton("RESERVAR AGORA");
        btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnNewButton_1.setForeground(new Color(0, 0, 0));
        btnNewButton_1.setBackground(new Color(0, 128, 192));
        btnNewButton_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/site-de-viagens.png")));
        
        JButton btnNewButton_1_1 = new JButton("RESERVAR AGORA");
        btnNewButton_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/site-de-viagens.png")));
        btnNewButton_1_1.setForeground(Color.BLACK);
        btnNewButton_1_1.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnNewButton_1_1.setBackground(new Color(0, 128, 192));
        
        JButton btnNewButton_2 = new JButton("");
        btnNewButton_2.setIcon(new ImageIcon(teste1.class.getResource("/imagens/simbolo-de-informacao.png")));
        btnNewButton_2.setBackground(new Color(0, 128, 192));
        
        JSeparator separator = new JSeparator();
        
        JSeparator separator_1 = new JSeparator();
        
        JButton btnNewButton_1_1_1 = new JButton("RESERVAR AGORA");
        btnNewButton_1_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/site-de-viagens.png")));
        btnNewButton_1_1_1.setForeground(Color.BLACK);
        btnNewButton_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnNewButton_1_1_1.setBackground(new Color(0, 128, 192));
        
        JButton btnNewButton_2_1 = new JButton("");
        btnNewButton_2_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/simbolo-de-informacao.png")));
        btnNewButton_2_1.setBackground(new Color(0, 128, 192));
        
        JButton btnNewButton_1_1_1_1 = new JButton("RESERVAR AGORA");
        btnNewButton_1_1_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/site-de-viagens.png")));
        btnNewButton_1_1_1_1.setForeground(Color.BLACK);
        btnNewButton_1_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnNewButton_1_1_1_1.setBackground(new Color(0, 128, 192));
        
        JLabel lblNewLabel_3_2_2 = new JLabel("");
        lblNewLabel_3_2_2.setBackground(new Color(255, 255, 255));
        lblNewLabel_3_2_2.setIcon(new ImageIcon(teste1.class.getResource("/imagens/WhatsApp Image 2024-09-06 at 22.53.36 (3).jpeg")));
        
        JButton btnNewButton_1_2 = new JButton("RESERVAR AGORA");
        btnNewButton_1_2.setIcon(new ImageIcon(teste1.class.getResource("/imagens/site-de-viagens.png")));
        btnNewButton_1_2.setForeground(Color.BLACK);
        btnNewButton_1_2.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnNewButton_1_2.setBackground(new Color(0, 128, 192));
        
        JButton btnNewButton_3 = new JButton("");
        btnNewButton_3.setIcon(new ImageIcon(teste1.class.getResource("/imagens/simbolo-de-informacao.png")));
        btnNewButton_3.setBackground(new Color(0, 128, 192));
        
        JButton btnNewButton_2_1_1 = new JButton("");
        btnNewButton_2_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/simbolo-de-informacao.png")));
        btnNewButton_2_1_1.setBackground(new Color(0, 128, 192));
        
        JLabel lblNewLabel_3_2_2_1 = new JLabel("");
        lblNewLabel_3_2_2_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/WhatsApp Image 2024-09-07 at 00.16.37 (4).jpeg")));
        
        JButton btnNewButton_1_2_1 = new JButton("RESERVAR AGORA");
        btnNewButton_1_2_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/site-de-viagens.png")));
        btnNewButton_1_2_1.setForeground(Color.BLACK);
        btnNewButton_1_2_1.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnNewButton_1_2_1.setBackground(new Color(0, 128, 192));
        
        JButton btnNewButton_3_1 = new JButton("");
        btnNewButton_3_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/simbolo-de-informacao.png")));
        btnNewButton_3_1.setBackground(new Color(0, 128, 192));
        
        JLabel lblNewLabel_3_2_2_1_1 = new JLabel("");
        lblNewLabel_3_2_2_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/WhatsApp Image 2024-09-06 at 22.53.36 (1) (1).jpeg")));
        
        JButton btnNewButton_1_2_1_1 = new JButton("RESERVAR AGORA");
        btnNewButton_1_2_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/site-de-viagens.png")));
        btnNewButton_1_2_1_1.setForeground(Color.BLACK);
        btnNewButton_1_2_1_1.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnNewButton_1_2_1_1.setBackground(new Color(0, 128, 192));
        
        JButton btnNewButton_3_1_1 = new JButton("");
        btnNewButton_3_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/simbolo-de-informacao.png")));
        btnNewButton_3_1_1.setBackground(new Color(0, 128, 192));
        
        JLabel lblNewLabel_3_2_2_1_1_1 = new JLabel("");
        lblNewLabel_3_2_2_1_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/WhatsApp Image 2024-09-07 at 00.16.37 (2) (1).jpeg")));
        
        JButton btnNewButton_1_2_1_1_1 = new JButton("RESERVAR AGORA");
        btnNewButton_1_2_1_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/site-de-viagens.png")));
        btnNewButton_1_2_1_1_1.setForeground(Color.BLACK);
        btnNewButton_1_2_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnNewButton_1_2_1_1_1.setBackground(new Color(0, 128, 192));
        
        JButton btnNewButton_3_1_1_1 = new JButton("");
        btnNewButton_3_1_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/simbolo-de-informacao.png")));
        btnNewButton_3_1_1_1.setBackground(new Color(0, 128, 192));
        
        JLabel lblNewLabel_3_2_2_1_1_1_1 = new JLabel("");
        lblNewLabel_3_2_2_1_1_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/WhatsApp Image 2024-09-07 at 00.16.36 (1) (1).jpeg")));
        
        JButton btnNewButton_1_2_1_1_1_1 = new JButton("RESERVAR AGORA");
        btnNewButton_1_2_1_1_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/site-de-viagens.png")));
        btnNewButton_1_2_1_1_1_1.setForeground(Color.BLACK);
        btnNewButton_1_2_1_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnNewButton_1_2_1_1_1_1.setBackground(new Color(0, 128, 192));
        
        JLabel lblNewLabel_3_2_1_1_2 = new JLabel("");
        lblNewLabel_3_2_1_1_2.setIcon(new ImageIcon(teste1.class.getResource("/imagens/WhatsApp Image 2024-09-07 at 00.42.54 (1).jpeg")));
        
        JButton btnNewButton_1_1_1_1_1 = new JButton("RESERVAR AGORA");
        btnNewButton_1_1_1_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/site-de-viagens.png")));
        btnNewButton_1_1_1_1_1.setForeground(Color.BLACK);
        btnNewButton_1_1_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnNewButton_1_1_1_1_1.setBackground(new Color(0, 128, 192));
        
        JButton btnNewButton_2_1_1_1 = new JButton("");
        btnNewButton_2_1_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/simbolo-de-informacao.png")));
        btnNewButton_2_1_1_1.setBackground(new Color(0, 128, 192));
        GroupLayout gl_panel_6 = new GroupLayout(panel_6);
        gl_panel_6.setHorizontalGroup(
        	gl_panel_6.createParallelGroup(Alignment.LEADING)
        		.addGroup(gl_panel_6.createSequentialGroup()
        			.addContainerGap()
        			.addGroup(gl_panel_6.createParallelGroup(Alignment.TRAILING)
        				.addGroup(gl_panel_6.createSequentialGroup()
        					.addGroup(gl_panel_6.createParallelGroup(Alignment.LEADING)
        						.addComponent(lblNewLabel_3_2, GroupLayout.PREFERRED_SIZE, 340, GroupLayout.PREFERRED_SIZE)
        						.addGroup(gl_panel_6.createSequentialGroup()
        							.addGap(31)
        							.addComponent(btnNewButton_1)
        							.addPreferredGap(ComponentPlacement.UNRELATED)
        							.addComponent(btnNewButton)))
        					.addPreferredGap(ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
        					.addGroup(gl_panel_6.createParallelGroup(Alignment.LEADING)
        						.addGroup(gl_panel_6.createSequentialGroup()
        							.addGap(10)
        							.addComponent(btnNewButton_1_1, GroupLayout.PREFERRED_SIZE, 180, GroupLayout.PREFERRED_SIZE)
        							.addGap(18)
        							.addComponent(btnNewButton_2, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE))
        						.addComponent(lblNewLabel_3_2_1_1_1, GroupLayout.PREFERRED_SIZE, 340, GroupLayout.PREFERRED_SIZE))
        					.addPreferredGap(ComponentPlacement.RELATED)
        					.addGroup(gl_panel_6.createParallelGroup(Alignment.LEADING)
        						.addComponent(lblNewLabel_3_2_1, GroupLayout.PREFERRED_SIZE, 340, GroupLayout.PREFERRED_SIZE)
        						.addGroup(gl_panel_6.createSequentialGroup()
        							.addGap(10)
        							.addComponent(btnNewButton_1_1_1, GroupLayout.PREFERRED_SIZE, 179, GroupLayout.PREFERRED_SIZE)
        							.addGap(18)
        							.addComponent(btnNewButton_2_1, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE))))
        				.addGroup(gl_panel_6.createSequentialGroup()
        					.addComponent(lblNewLabel_3_2_2, GroupLayout.PREFERRED_SIZE, 340, GroupLayout.PREFERRED_SIZE)
        					.addPreferredGap(ComponentPlacement.RELATED)
        					.addComponent(lblNewLabel_3_2_2_1, GroupLayout.PREFERRED_SIZE, 340, GroupLayout.PREFERRED_SIZE)
        					.addPreferredGap(ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
        					.addComponent(lblNewLabel_3_2_2_1_1, GroupLayout.PREFERRED_SIZE, 340, GroupLayout.PREFERRED_SIZE)))
        			.addGap(18)
        			.addGroup(gl_panel_6.createParallelGroup(Alignment.LEADING)
        				.addGroup(gl_panel_6.createSequentialGroup()
        					.addComponent(lblNewLabel_3_2_1_1, GroupLayout.PREFERRED_SIZE, 340, GroupLayout.PREFERRED_SIZE)
        					.addPreferredGap(ComponentPlacement.UNRELATED)
        					.addComponent(lblNewLabel_3_2_1_1_2, GroupLayout.PREFERRED_SIZE, 340, GroupLayout.PREFERRED_SIZE)
        					.addPreferredGap(ComponentPlacement.RELATED)
        					.addComponent(separator, GroupLayout.PREFERRED_SIZE, 2, GroupLayout.PREFERRED_SIZE)
        					.addGap(1275)
        					.addComponent(separator_1, GroupLayout.PREFERRED_SIZE, 1, GroupLayout.PREFERRED_SIZE))
        				.addGroup(gl_panel_6.createSequentialGroup()
        					.addGap(10)
        					.addGroup(gl_panel_6.createParallelGroup(Alignment.LEADING)
        						.addGroup(gl_panel_6.createSequentialGroup()
        							.addComponent(btnNewButton_1_1_1_1, GroupLayout.PREFERRED_SIZE, 179, GroupLayout.PREFERRED_SIZE)
        							.addGap(17)
        							.addComponent(btnNewButton_2_1_1, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE)
        							.addGap(97)
        							.addComponent(btnNewButton_1_1_1_1_1, GroupLayout.PREFERRED_SIZE, 179, GroupLayout.PREFERRED_SIZE)
        							.addGap(18)
        							.addComponent(btnNewButton_2_1_1_1, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE))
        						.addGroup(gl_panel_6.createSequentialGroup()
        							.addGroup(gl_panel_6.createParallelGroup(Alignment.LEADING)
        								.addComponent(lblNewLabel_3_2_2_1_1_1, GroupLayout.PREFERRED_SIZE, 340, GroupLayout.PREFERRED_SIZE)
        								.addGroup(gl_panel_6.createSequentialGroup()
        									.addGap(10)
        									.addComponent(btnNewButton_1_2_1_1_1, GroupLayout.PREFERRED_SIZE, 177, GroupLayout.PREFERRED_SIZE)))
        							.addPreferredGap(ComponentPlacement.RELATED)
        							.addGroup(gl_panel_6.createParallelGroup(Alignment.LEADING)
        								.addGroup(gl_panel_6.createSequentialGroup()
        									.addGap(10)
        									.addComponent(btnNewButton_1_2_1_1_1_1, GroupLayout.PREFERRED_SIZE, 177, GroupLayout.PREFERRED_SIZE))
        								.addComponent(lblNewLabel_3_2_2_1_1_1_1, GroupLayout.PREFERRED_SIZE, 340, GroupLayout.PREFERRED_SIZE))))))
        			.addGap(2351))
        		.addGroup(gl_panel_6.createSequentialGroup()
        			.addGap(37)
        			.addComponent(btnNewButton_1_2, GroupLayout.PREFERRED_SIZE, 169, GroupLayout.PREFERRED_SIZE)
        			.addGap(18)
        			.addComponent(btnNewButton_3, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE)
        			.addGap(98)
        			.addComponent(btnNewButton_1_2_1, GroupLayout.PREFERRED_SIZE, 169, GroupLayout.PREFERRED_SIZE)
        			.addGap(18)
        			.addComponent(btnNewButton_3_1, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE)
        			.addGap(85)
        			.addComponent(btnNewButton_1_2_1_1, GroupLayout.PREFERRED_SIZE, 180, GroupLayout.PREFERRED_SIZE)
        			.addGap(18)
        			.addComponent(btnNewButton_3_1_1, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE)
        			.addGap(301)
        			.addComponent(btnNewButton_3_1_1_1, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE)
        			.addContainerGap(4051, Short.MAX_VALUE))
        );
        gl_panel_6.setVerticalGroup(
        	gl_panel_6.createParallelGroup(Alignment.LEADING)
        		.addGroup(gl_panel_6.createSequentialGroup()
        			.addGroup(gl_panel_6.createParallelGroup(Alignment.LEADING)
        				.addGroup(gl_panel_6.createSequentialGroup()
        					.addContainerGap()
        					.addGroup(gl_panel_6.createParallelGroup(Alignment.LEADING)
        						.addComponent(separator_1, GroupLayout.PREFERRED_SIZE, 442, GroupLayout.PREFERRED_SIZE)
        						.addComponent(separator, GroupLayout.PREFERRED_SIZE, 430, GroupLayout.PREFERRED_SIZE)))
        				.addGroup(gl_panel_6.createSequentialGroup()
        					.addGroup(gl_panel_6.createParallelGroup(Alignment.LEADING)
        						.addComponent(lblNewLabel_3_2)
        						.addComponent(lblNewLabel_3_2_1_1_1, GroupLayout.PREFERRED_SIZE, 533, GroupLayout.PREFERRED_SIZE))
        					.addPreferredGap(ComponentPlacement.RELATED)
        					.addGroup(gl_panel_6.createParallelGroup(Alignment.LEADING)
        						.addComponent(btnNewButton_1_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
        						.addComponent(btnNewButton_2, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
        						.addGroup(gl_panel_6.createParallelGroup(Alignment.TRAILING)
        							.addComponent(btnNewButton_1)
        							.addComponent(btnNewButton))))
        				.addGroup(gl_panel_6.createSequentialGroup()
        					.addComponent(lblNewLabel_3_2_1, GroupLayout.PREFERRED_SIZE, 533, GroupLayout.PREFERRED_SIZE)
        					.addPreferredGap(ComponentPlacement.RELATED)
        					.addGroup(gl_panel_6.createParallelGroup(Alignment.LEADING)
        						.addComponent(btnNewButton_2_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
        						.addComponent(btnNewButton_1_1_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)))
        				.addGroup(gl_panel_6.createSequentialGroup()
        					.addComponent(lblNewLabel_3_2_1_1, GroupLayout.PREFERRED_SIZE, 533, GroupLayout.PREFERRED_SIZE)
        					.addPreferredGap(ComponentPlacement.RELATED)
        					.addGroup(gl_panel_6.createParallelGroup(Alignment.LEADING)
        						.addComponent(btnNewButton_2_1_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
        						.addComponent(btnNewButton_1_1_1_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)))
        				.addGroup(gl_panel_6.createSequentialGroup()
        					.addComponent(lblNewLabel_3_2_1_1_2, GroupLayout.PREFERRED_SIZE, 533, GroupLayout.PREFERRED_SIZE)
        					.addPreferredGap(ComponentPlacement.RELATED)
        					.addGroup(gl_panel_6.createParallelGroup(Alignment.LEADING)
        						.addComponent(btnNewButton_2_1_1_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
        						.addComponent(btnNewButton_1_1_1_1_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE))))
        			.addGap(36)
        			.addGroup(gl_panel_6.createParallelGroup(Alignment.LEADING)
        				.addGroup(gl_panel_6.createSequentialGroup()
        					.addGroup(gl_panel_6.createParallelGroup(Alignment.LEADING)
        						.addComponent(lblNewLabel_3_2_2_1, GroupLayout.PREFERRED_SIZE, 533, GroupLayout.PREFERRED_SIZE)
        						.addComponent(lblNewLabel_3_2_2, GroupLayout.PREFERRED_SIZE, 533, GroupLayout.PREFERRED_SIZE)
        						.addComponent(lblNewLabel_3_2_2_1_1, GroupLayout.PREFERRED_SIZE, 533, GroupLayout.PREFERRED_SIZE))
        					.addPreferredGap(ComponentPlacement.RELATED)
        					.addGroup(gl_panel_6.createParallelGroup(Alignment.LEADING)
        						.addComponent(btnNewButton_1_2_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
        						.addComponent(btnNewButton_1_2, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
        						.addComponent(btnNewButton_1_2_1_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
        						.addComponent(btnNewButton_3, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
        						.addComponent(btnNewButton_3_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
        						.addComponent(btnNewButton_3_1_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)))
        				.addGroup(gl_panel_6.createSequentialGroup()
        					.addComponent(lblNewLabel_3_2_2_1_1_1, GroupLayout.PREFERRED_SIZE, 533, GroupLayout.PREFERRED_SIZE)
        					.addPreferredGap(ComponentPlacement.RELATED)
        					.addGroup(gl_panel_6.createParallelGroup(Alignment.LEADING)
        						.addComponent(btnNewButton_1_2_1_1_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
        						.addComponent(btnNewButton_3_1_1_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)))
        				.addGroup(gl_panel_6.createSequentialGroup()
        					.addComponent(lblNewLabel_3_2_2_1_1_1_1, GroupLayout.PREFERRED_SIZE, 533, GroupLayout.PREFERRED_SIZE)
        					.addPreferredGap(ComponentPlacement.RELATED)
        					.addComponent(btnNewButton_1_2_1_1_1_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)))
        			.addContainerGap(437, Short.MAX_VALUE))
        );
        panel_6.setLayout(gl_panel_6);
        
        JPanel panel = new JPanel();
        panel.setBackground(new Color(255, 255, 255));
        tabbedPane.addTab("PRECISA DE AJUDA?", new ImageIcon(teste1.class.getResource("/imagens/ponto-de-interrogacao.png")), panel, null);
        
        JLabel lblNewLabel = new JLabel("");
        lblNewLabel.setIcon(new ImageIcon(teste1.class.getResource("/imagens/WhatsApp Image 2024-09-06 at 13.23.19 (1).jpeg")));
        
        JLabel lblNewLabel2_1 = new JLabel("CENTRAL DE ATENDIMENTO");
        lblNewLabel2_1.setFont(new Font("Tahoma", Font.BOLD, 14));
        
        JButton btnNewButton_4 = new JButton("Suporte Pós Venda (85)99686-2704");
        btnNewButton_4.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		try {
					String url = "https://p.freecallinc.com/voip/browser-phone/browser-phone.php?cid=1326&sid=1298&sys=1725923568077gfa5c6zua4z3bqc7qpn&uid=&uml=&unm=&lng=portuguese&http_refferer=&CacheCiller=66df818137b5e&dtitle=Chamada%20Gr%C3%A1tis&js_http_reff=https%3A%2F%2Fwww.freecallinc.com%2Flanguages%2Fportuguese%2F";
					if (Desktop.isDesktopSupported()) {
						Desktop desktop = Desktop.getDesktop();
						desktop.browse(new URI(url));
					} else {
						System.out.println("Desktop não suportado.");
					}
				} catch (Exception ex) {
					ex.printStackTrace();
				}
        	}
        });
        btnNewButton_4.setBackground(new Color(255, 255, 255));
        
        JTextPane txtpnSegundaSbado = new JTextPane();
        txtpnSegundaSbado.setText("Segunda à Sábado: 08h às 21h\r\n\r\nRemarcação de viagens");
        
        JButton btnNewButton_4_1 = new JButton("Central de relacionamento ao cliente (85)99796-1409");
        btnNewButton_4_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		try {
					String url = "https://p.freecallinc.com/voip/browser-phone/browser-phone.php?cid=1326&sid=1298&sys=1725923568077gfa5c6zua4z3bqc7qpn&uid=&uml=&unm=&lng=portuguese&http_refferer=&CacheCiller=66df818137b5e&dtitle=Chamada%20Gr%C3%A1tis&js_http_reff=https%3A%2F%2Fwww.freecallinc.com%2Flanguages%2Fportuguese%2F";
					if (Desktop.isDesktopSupported()) {
						Desktop desktop = Desktop.getDesktop();
						desktop.browse(new URI(url));
					} else {
						System.out.println("Desktop não suportado.");
					}
				} catch (Exception ex) {
					ex.printStackTrace();
				}	
        	}
        });
        btnNewButton_4_1.setBackground(new Color(255, 255, 255));
        
        JTextPane txtpnSegundaSexta = new JTextPane();
        txtpnSegundaSexta.setText("Segunda à Sexta: 08h às 21h\r\n\r\nSábado e Feriados: 08h às 16h\r\n\r\n");
        
        JLabel lblContato = new JLabel("CONTATO");
        lblContato.setFont(new Font("Tahoma", Font.BOLD, 18));
        
        JLabel nome = new JLabel("NOME");
        nome.setFont(new Font("Tahoma", Font.BOLD, 14));
        
        JLabel sobrenome = new JLabel("SOBRENOME");
        sobrenome.setFont(new Font("Tahoma", Font.BOLD, 14));
        
        textField = new JTextField();
        textField.setColumns(10);
        
        textField_1 = new JTextField();
        textField_1.setColumns(10);
        
        JLabel email = new JLabel("EMAIL*");
        email.setFont(new Font("Tahoma", Font.BOLD, 14));
        
        textField_2 = new JTextField();
        textField_2.setColumns(10);
        
        textField_3 = new JTextField();
        textField_3.setColumns(10);
        
        JLabel lblMensagem = new JLabel("MENSAGEM*");
        lblMensagem.setFont(new Font("Tahoma", Font.BOLD, 14));
        
        textField_4 = new JTextField();
        textField_4.setColumns(10);
        
        JLabel lblTelefone = new JLabel("TELEFONE");
        lblTelefone.setFont(new Font("Tahoma", Font.BOLD, 14));
        
        JButton btnNewButton_5 = new JButton("");
        btnNewButton_5.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		try {
					String url = "https://www.instagram.com/";
					if (Desktop.isDesktopSupported()) {
						Desktop desktop = Desktop.getDesktop();
						desktop.browse(new URI(url));
					} else {
						System.out.println("Desktop não suportado.");
					}
				} catch (Exception ex) {
					ex.printStackTrace();
				}
        	}
        	});
        btnNewButton_5.setBackground(new Color(255, 255, 255));
        btnNewButton_5.setIcon(new ImageIcon(teste1.class.getResource("/imagens/instagram.png")));
        
        JButton btnNewButton_5_1 = new JButton("");
        btnNewButton_5_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		try {
					String url = "https://pt-br.facebook.com/";
					if (Desktop.isDesktopSupported()) {
						Desktop desktop = Desktop.getDesktop();
						desktop.browse(new URI(url));
					} else {
						System.out.println("Desktop não suportado.");
					}
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
        	
        });
        btnNewButton_5_1.setBackground(new Color(255, 255, 255));
        btnNewButton_5_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/facebook.png")));
        
        JButton btnNewButton_5_1_1 = new JButton("");
        btnNewButton_5_1_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		try {
					String url = "https://www.tripadvisor.com.br/";
					if (Desktop.isDesktopSupported()) {
						Desktop desktop = Desktop.getDesktop();
						desktop.browse(new URI(url));
					} else {
						System.out.println("Desktop não suportado.");
					}
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}	
        });
        btnNewButton_5_1_1.setBackground(new Color(255, 255, 255));
        btnNewButton_5_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/tripadvisor.png")));
        
        JLabel lblNewLabel2_1_1 = new JLabel("SIGA OFERTAS NAS REDES");
        lblNewLabel2_1_1.setFont(new Font("Tahoma", Font.BOLD, 14));
        
        JButton btnNewButton_5_1_1_1 = new JButton("ENTRE EM CONTATO CONOSCO PELO WHATSAPP");
        btnNewButton_5_1_1_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		try {
					String url = "https://api.whatsapp.com/send?phone=5585996702918&text=Olá,%20Gostaria%20de%20falar%20com%20um%20atendente.";
					if (Desktop.isDesktopSupported()) {
						Desktop desktop = Desktop.getDesktop();
						desktop.browse(new URI(url));
					} else {
						System.out.println("Desktop não suportado.");
					}
				} catch (Exception ex) {
					ex.printStackTrace();
				}
        	}
        });
        btnNewButton_5_1_1_1.setBackground(new Color(255, 255, 255));
        btnNewButton_5_1_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/whatsapp.png")));
        
        JTextPane txtpnCvcBrasilOperadora = new JTextPane();
        txtpnCvcBrasilOperadora.setText("WORLD TUR Brasil Operadora e Agência de Viagens S.A \r\nCNPJ:10.760.260/0001-19\r\nAV.Desembargador Moreira, 227, 11 andar, sala 111 \r\nBairro Aldeota, Fortaleza- CE\r\nCEP: 60170-002");
        
        JButton btnNewButton_6 = new JButton("ENVIAR");
        btnNewButton_6.setBackground(new Color(255, 255, 255));
        
        JScrollPane scrollPane_2 = new JScrollPane();
        
        JScrollPane scrollPane_3 = new JScrollPane();
        GroupLayout gl_panel = new GroupLayout(panel);
        gl_panel.setHorizontalGroup(
        	gl_panel.createParallelGroup(Alignment.LEADING)
        		.addGroup(gl_panel.createSequentialGroup()
        			.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
        				.addComponent(scrollPane_2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        				.addGroup(gl_panel.createSequentialGroup()
        					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
        						.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
        							.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
        								.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 348, GroupLayout.PREFERRED_SIZE)
        								.addGroup(gl_panel.createSequentialGroup()
        									.addGap(44)
        									.addGroup(gl_panel.createParallelGroup(Alignment.LEADING, false)
        										.addComponent(txtpnSegundaSbado, GroupLayout.PREFERRED_SIZE, 188, GroupLayout.PREFERRED_SIZE)
        										.addComponent(btnNewButton_4_1, GroupLayout.DEFAULT_SIZE, 304, Short.MAX_VALUE)
        										.addComponent(btnNewButton_4, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        										.addComponent(txtpnSegundaSexta, GroupLayout.PREFERRED_SIZE, 188, GroupLayout.PREFERRED_SIZE)
        										.addGroup(gl_panel.createSequentialGroup()
        											.addComponent(btnNewButton_5)
        											.addGap(18)
        											.addComponent(btnNewButton_5_1, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE)
        											.addGap(18)
        											.addComponent(btnNewButton_5_1_1, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE)))))
        							.addGroup(gl_panel.createSequentialGroup()
        								.addGap(91)
        								.addComponent(lblNewLabel2_1, GroupLayout.PREFERRED_SIZE, 215, GroupLayout.PREFERRED_SIZE)))
        						.addGroup(gl_panel.createSequentialGroup()
        							.addGap(73)
        							.addComponent(lblNewLabel2_1_1, GroupLayout.PREFERRED_SIZE, 215, GroupLayout.PREFERRED_SIZE)))
        					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
        						.addGroup(gl_panel.createSequentialGroup()
        							.addGap(139)
        							.addComponent(scrollPane_3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        							.addGap(268)
        							.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
        								.addComponent(lblMensagem, GroupLayout.PREFERRED_SIZE, 114, GroupLayout.PREFERRED_SIZE)
        								.addGroup(gl_panel.createSequentialGroup()
        									.addGap(254)
        									.addComponent(lblContato, GroupLayout.PREFERRED_SIZE, 114, GroupLayout.PREFERRED_SIZE))
        								.addGroup(gl_panel.createSequentialGroup()
        									.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
        										.addComponent(email, GroupLayout.PREFERRED_SIZE, 114, GroupLayout.PREFERRED_SIZE)
        										.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, 255, GroupLayout.PREFERRED_SIZE))
        									.addGap(167)
        									.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
        										.addComponent(textField_3, GroupLayout.PREFERRED_SIZE, 255, GroupLayout.PREFERRED_SIZE)
        										.addComponent(lblTelefone, GroupLayout.PREFERRED_SIZE, 114, GroupLayout.PREFERRED_SIZE)))
        								.addGroup(gl_panel.createSequentialGroup()
        									.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
        										.addComponent(nome, GroupLayout.PREFERRED_SIZE, 114, GroupLayout.PREFERRED_SIZE)
        										.addComponent(textField, GroupLayout.PREFERRED_SIZE, 255, GroupLayout.PREFERRED_SIZE))
        									.addGap(167)
        									.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
        										.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, 255, GroupLayout.PREFERRED_SIZE)
        										.addComponent(sobrenome, GroupLayout.PREFERRED_SIZE, 114, GroupLayout.PREFERRED_SIZE)))
        								.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING)
        									.addComponent(btnNewButton_6)
        									.addComponent(textField_4, GroupLayout.PREFERRED_SIZE, 554, GroupLayout.PREFERRED_SIZE)
        									.addComponent(btnNewButton_5_1_1_1, GroupLayout.PREFERRED_SIZE, 498, GroupLayout.PREFERRED_SIZE))))
        						.addGroup(gl_panel.createSequentialGroup()
        							.addGap(798)
        							.addComponent(txtpnCvcBrasilOperadora, GroupLayout.PREFERRED_SIZE, 330, GroupLayout.PREFERRED_SIZE)))
        					.addGap(33)))
        			.addContainerGap(8658, Short.MAX_VALUE))
        );
        gl_panel.setVerticalGroup(
        	gl_panel.createParallelGroup(Alignment.LEADING)
        		.addGroup(gl_panel.createSequentialGroup()
        			.addGap(208)
        			.addComponent(scrollPane_3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        			.addContainerGap(1763, Short.MAX_VALUE))
        		.addGroup(gl_panel.createSequentialGroup()
        			.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
        				.addGroup(gl_panel.createSequentialGroup()
        					.addContainerGap()
        					.addComponent(scrollPane_2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        					.addPreferredGap(ComponentPlacement.RELATED)
        					.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 285, GroupLayout.PREFERRED_SIZE)
        					.addGap(30)
        					.addComponent(lblNewLabel2_1)
        					.addGap(37)
        					.addComponent(btnNewButton_4, GroupLayout.PREFERRED_SIZE, 34, GroupLayout.PREFERRED_SIZE)
        					.addPreferredGap(ComponentPlacement.UNRELATED)
        					.addComponent(txtpnSegundaSbado, GroupLayout.PREFERRED_SIZE, 57, GroupLayout.PREFERRED_SIZE)
        					.addPreferredGap(ComponentPlacement.UNRELATED)
        					.addComponent(btnNewButton_4_1, GroupLayout.PREFERRED_SIZE, 34, GroupLayout.PREFERRED_SIZE))
        				.addGroup(gl_panel.createSequentialGroup()
        					.addGap(42)
        					.addComponent(lblContato, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE)
        					.addGap(40)
        					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
        						.addComponent(nome, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE)
        						.addComponent(sobrenome, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE))
        					.addPreferredGap(ComponentPlacement.RELATED)
        					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
        						.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        						.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
        					.addGap(35)
        					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
        						.addComponent(email, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE)
        						.addComponent(lblTelefone, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE))
        					.addGap(11)
        					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
        						.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        						.addComponent(textField_3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
        					.addPreferredGap(ComponentPlacement.UNRELATED)
        					.addComponent(lblMensagem, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE)
        					.addGap(18)
        					.addComponent(textField_4, GroupLayout.PREFERRED_SIZE, 138, GroupLayout.PREFERRED_SIZE)
        					.addGap(18)
        					.addComponent(btnNewButton_6)))
        			.addGap(18)
        			.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
        				.addGroup(gl_panel.createSequentialGroup()
        					.addComponent(btnNewButton_5_1_1_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
        					.addGap(18)
        					.addComponent(txtpnCvcBrasilOperadora, GroupLayout.PREFERRED_SIZE, 98, GroupLayout.PREFERRED_SIZE))
        				.addGroup(gl_panel.createSequentialGroup()
        					.addComponent(txtpnSegundaSexta, GroupLayout.PREFERRED_SIZE, 57, GroupLayout.PREFERRED_SIZE)
        					.addGap(18)
        					.addComponent(lblNewLabel2_1_1, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE)
        					.addGap(18)
        					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
        						.addComponent(btnNewButton_5)
        						.addComponent(btnNewButton_5_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
        						.addComponent(btnNewButton_5_1_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE))))
        			.addGap(1258))
        );
        panel.setLayout(gl_panel);
        
        JPanel panel_3 = new JPanel();
        tabbedPane.addTab("PACOTES PARA SE DIVERTIR", new ImageIcon(teste1.class.getResource("/imagens/roda-gigante.png")), panel_3, null);
        
        JLabel lblNewLabel_2 = new JLabel("New label");
        lblNewLabel_2.setIcon(new ImageIcon(teste1.class.getResource("/imagens/WhatsApp Image 2024-09-10 at 11.25.23 (1).jpeg")));
        
        JLabel lblNewLabel_2_1 = new JLabel("New label");
        lblNewLabel_2_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/WhatsApp Image 2024-09-10 at 00.33.03 (4).jpeg")));
        
        JLabel lblNewLabel_2_2 = new JLabel("New label");
        lblNewLabel_2_2.setIcon(new ImageIcon(teste1.class.getResource("/imagens/WhatsApp Image 2024-09-10 at 11.25.28 (2).jpeg")));
        
        JLabel lblNewLabel_2_2_1 = new JLabel("New label");
        lblNewLabel_2_2_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/WhatsApp Image 2024-09-10 at 00.33.03 (5).jpeg")));
        
        JLabel lblNewLabel_2_1_1 = new JLabel("New label");
        lblNewLabel_2_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/WhatsApp Image 2024-09-10 at 00.33.03 (6).jpeg")));
        
        JButton btnNewButton_1_3_3 = new JButton("RESERVAR AGORA");
        btnNewButton_1_3_3.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        	}
        });
        btnNewButton_1_3_3.setIcon(new ImageIcon(teste1.class.getResource("/imagens/site-de-viagens.png")));
        btnNewButton_1_3_3.setForeground(Color.BLACK);
        btnNewButton_1_3_3.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnNewButton_1_3_3.setBackground(new Color(0, 128, 192));
        
        JButton btnNewButton_7_3 = new JButton("");
        btnNewButton_7_3.setIcon(new ImageIcon(teste1.class.getResource("/imagens/simbolo-de-informacao.png")));
        btnNewButton_7_3.setBackground(new Color(0, 128, 192));
        
        JButton btnNewButton_1_3_3_1 = new JButton("RESERVAR AGORA");
        btnNewButton_1_3_3_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/site-de-viagens.png")));
        btnNewButton_1_3_3_1.setForeground(Color.BLACK);
        btnNewButton_1_3_3_1.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnNewButton_1_3_3_1.setBackground(new Color(0, 128, 192));
        
        JButton btnNewButton_7_3_1 = new JButton("");
        btnNewButton_7_3_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/simbolo-de-informacao.png")));
        btnNewButton_7_3_1.setBackground(new Color(0, 128, 192));
        
        JButton btnNewButton_1_3_3_1_1 = new JButton("RESERVAR AGORA");
        btnNewButton_1_3_3_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/site-de-viagens.png")));
        btnNewButton_1_3_3_1_1.setForeground(Color.BLACK);
        btnNewButton_1_3_3_1_1.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnNewButton_1_3_3_1_1.setBackground(new Color(0, 128, 192));
        
        JButton btnNewButton_7_3_1_1 = new JButton("");
        btnNewButton_7_3_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/simbolo-de-informacao.png")));
        btnNewButton_7_3_1_1.setBackground(new Color(0, 128, 192));
        
        JButton btnNewButton_1_3_3_2 = new JButton("RESERVAR AGORA");
        btnNewButton_1_3_3_2.setIcon(new ImageIcon(teste1.class.getResource("/imagens/site-de-viagens.png")));
        btnNewButton_1_3_3_2.setForeground(Color.BLACK);
        btnNewButton_1_3_3_2.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnNewButton_1_3_3_2.setBackground(new Color(0, 128, 192));
        
        JButton btnNewButton_7_3_2 = new JButton("");
        btnNewButton_7_3_2.setIcon(new ImageIcon(teste1.class.getResource("/imagens/simbolo-de-informacao.png")));
        btnNewButton_7_3_2.setBackground(new Color(0, 128, 192));
        
        JButton btnNewButton_1_3_3_2_1 = new JButton("RESERVAR AGORA");
        btnNewButton_1_3_3_2_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/site-de-viagens.png")));
        btnNewButton_1_3_3_2_1.setForeground(Color.BLACK);
        btnNewButton_1_3_3_2_1.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnNewButton_1_3_3_2_1.setBackground(new Color(0, 128, 192));
        
        JButton btnNewButton_7_3_2_1 = new JButton("");
        btnNewButton_7_3_2_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/simbolo-de-informacao.png")));
        btnNewButton_7_3_2_1.setBackground(new Color(0, 128, 192));
        GroupLayout gl_panel_3 = new GroupLayout(panel_3);
        gl_panel_3.setHorizontalGroup(
        	gl_panel_3.createParallelGroup(Alignment.LEADING)
        		.addGroup(gl_panel_3.createSequentialGroup()
        			.addGap(51)
        			.addGroup(gl_panel_3.createParallelGroup(Alignment.LEADING)
        				.addGroup(gl_panel_3.createSequentialGroup()
        					.addComponent(lblNewLabel_2, GroupLayout.PREFERRED_SIZE, 300, GroupLayout.PREFERRED_SIZE)
        					.addGap(55)
        					.addComponent(lblNewLabel_2_1, GroupLayout.PREFERRED_SIZE, 300, GroupLayout.PREFERRED_SIZE)
        					.addGap(51)
        					.addComponent(lblNewLabel_2_1_1, GroupLayout.PREFERRED_SIZE, 300, GroupLayout.PREFERRED_SIZE))
        				.addGroup(gl_panel_3.createSequentialGroup()
        					.addGap(8)
        					.addGroup(gl_panel_3.createParallelGroup(Alignment.LEADING)
        						.addGroup(gl_panel_3.createSequentialGroup()
        							.addComponent(btnNewButton_1_3_3, GroupLayout.PREFERRED_SIZE, 181, GroupLayout.PREFERRED_SIZE)
        							.addGap(18)
        							.addComponent(btnNewButton_7_3, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE))
        						.addComponent(lblNewLabel_2_2, GroupLayout.PREFERRED_SIZE, 300, GroupLayout.PREFERRED_SIZE)
        						.addGroup(gl_panel_3.createSequentialGroup()
        							.addGap(13)
        							.addComponent(btnNewButton_1_3_3_2, GroupLayout.PREFERRED_SIZE, 181, GroupLayout.PREFERRED_SIZE)
        							.addGap(18)
        							.addComponent(btnNewButton_7_3_2, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE)))
        					.addGroup(gl_panel_3.createParallelGroup(Alignment.LEADING)
        						.addGroup(gl_panel_3.createSequentialGroup()
        							.addGap(59)
        							.addGroup(gl_panel_3.createParallelGroup(Alignment.LEADING)
        								.addGroup(gl_panel_3.createSequentialGroup()
        									.addComponent(btnNewButton_1_3_3_1, GroupLayout.PREFERRED_SIZE, 181, GroupLayout.PREFERRED_SIZE)
        									.addGap(18)
        									.addComponent(btnNewButton_7_3_1, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE)
        									.addGap(91)
        									.addComponent(btnNewButton_1_3_3_1_1, GroupLayout.PREFERRED_SIZE, 181, GroupLayout.PREFERRED_SIZE)
        									.addGap(18)
        									.addComponent(btnNewButton_7_3_1_1, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE))
        								.addComponent(lblNewLabel_2_2_1, GroupLayout.PREFERRED_SIZE, 300, GroupLayout.PREFERRED_SIZE)))
        						.addGroup(gl_panel_3.createSequentialGroup()
        							.addGap(77)
        							.addComponent(btnNewButton_1_3_3_2_1, GroupLayout.PREFERRED_SIZE, 181, GroupLayout.PREFERRED_SIZE)
        							.addGap(18)
        							.addComponent(btnNewButton_7_3_2_1, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE)))))
        			.addContainerGap(9110, Short.MAX_VALUE))
        );
        gl_panel_3.setVerticalGroup(
        	gl_panel_3.createParallelGroup(Alignment.LEADING)
        		.addGroup(gl_panel_3.createSequentialGroup()
        			.addContainerGap()
        			.addGroup(gl_panel_3.createParallelGroup(Alignment.LEADING)
        				.addGroup(gl_panel_3.createSequentialGroup()
        					.addComponent(lblNewLabel_2_1_1, GroupLayout.PREFERRED_SIZE, 448, GroupLayout.PREFERRED_SIZE)
        					.addGap(18)
        					.addGroup(gl_panel_3.createParallelGroup(Alignment.LEADING)
        						.addComponent(btnNewButton_7_3_1_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
        						.addComponent(btnNewButton_1_3_3_1_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)))
        				.addGroup(gl_panel_3.createSequentialGroup()
        					.addGroup(gl_panel_3.createParallelGroup(Alignment.LEADING)
        						.addComponent(lblNewLabel_2_1, GroupLayout.PREFERRED_SIZE, 448, GroupLayout.PREFERRED_SIZE)
        						.addComponent(lblNewLabel_2, GroupLayout.PREFERRED_SIZE, 448, GroupLayout.PREFERRED_SIZE))
        					.addGap(18)
        					.addGroup(gl_panel_3.createParallelGroup(Alignment.LEADING)
        						.addComponent(btnNewButton_1_3_3_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
        						.addComponent(btnNewButton_7_3_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
        						.addComponent(btnNewButton_1_3_3, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
        						.addComponent(btnNewButton_7_3, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE))
        					.addGap(102)
        					.addGroup(gl_panel_3.createParallelGroup(Alignment.BASELINE)
        						.addComponent(lblNewLabel_2_2, GroupLayout.PREFERRED_SIZE, 448, GroupLayout.PREFERRED_SIZE)
        						.addComponent(lblNewLabel_2_2_1, GroupLayout.PREFERRED_SIZE, 448, GroupLayout.PREFERRED_SIZE))
        					.addGap(18)
        					.addGroup(gl_panel_3.createParallelGroup(Alignment.LEADING)
        						.addComponent(btnNewButton_7_3_2_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
        						.addComponent(btnNewButton_1_3_3_2_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
        						.addComponent(btnNewButton_7_3_2, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
        						.addComponent(btnNewButton_1_3_3_2, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE))))
        			.addContainerGap(846, Short.MAX_VALUE))
        );
        panel_3.setLayout(gl_panel_3);
        
        JPanel panel_1 = new JPanel();
        tabbedPane.addTab("PACOTES NACIONAIS", new ImageIcon(teste1.class.getResource("/imagens/viajar-por.png")), panel_1, null);
        
        JScrollPane scrollPane_1 = new JScrollPane();
        
        JLabel lblNewLabel_1 = new JLabel("");
        lblNewLabel_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/WhatsApp Image 2024-09-09 at 20.25.47 (1).jpeg")));
        
        JLabel lblNewLabel_1_1 = new JLabel("");
        lblNewLabel_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/WhatsApp Image 2024-09-09 at 20.25.50 (4).jpeg")));
        
        JLabel lblNewLabel_1_1_1 = new JLabel("");
        lblNewLabel_1_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/WhatsApp Image 2024-09-09 at 20.25.49 (1) (1).jpeg")));
        
        JScrollPane scrollPane_4 = new JScrollPane();
        
        JLabel lblNewLabel_1_1_1_1 = new JLabel("");
        lblNewLabel_1_1_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/WhatsApp Image 2024-09-09 at 20.35.01 (1).jpeg")));
        
        JLabel lblNewLabel_1_1_1_1_1 = new JLabel("");
        lblNewLabel_1_1_1_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/WhatsApp Image 2024-09-09 at 20.45.10 (1).jpeg")));
        
        JLabel lblNewLabel_1_1_1_1_2 = new JLabel("");
        lblNewLabel_1_1_1_1_2.setIcon(new ImageIcon(teste1.class.getResource("/imagens/WhatsApp Image 2024-09-09 at 20.25.49 (2) (1).jpeg")));
        
        JLabel lblNewLabel_1_1_1_1_2_1 = new JLabel("");
        lblNewLabel_1_1_1_1_2_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/WhatsApp Image 2024-09-09 at 20.25.50 (1) (1).jpeg")));
        
        JLabel lblNewLabel_1_1_1_1_2_1_1 = new JLabel("");
        lblNewLabel_1_1_1_1_2_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/WhatsApp Image 2024-09-09 at 20.25.49 (3).jpeg")));
        
        JLabel lblNewLabel_1_1_1_1_2_1_1_1 = new JLabel("");
        lblNewLabel_1_1_1_1_2_1_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/WhatsApp Image 2024-09-09 at 20.25.50 (3) (1).jpeg")));
        
        JLabel lblNewLabel_1_1_1_1_2_1_1_1_1 = new JLabel("");
        lblNewLabel_1_1_1_1_2_1_1_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/WhatsApp Image 2024-09-09 at 20.25.50 (2) (1).jpeg")));
        
        JButton btnNewButton_1_3 = new JButton("RESERVAR AGORA");
        btnNewButton_1_3.setIcon(new ImageIcon(teste1.class.getResource("/imagens/site-de-viagens.png")));
        btnNewButton_1_3.setForeground(Color.BLACK);
        btnNewButton_1_3.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnNewButton_1_3.setBackground(new Color(0, 128, 192));
        
        JButton btnNewButton_7 = new JButton("");
        btnNewButton_7.setBackground(new Color(0, 128, 192));
        btnNewButton_7.setIcon(new ImageIcon(teste1.class.getResource("/imagens/simbolo-de-informacao.png")));
        
        JButton btnNewButton_1_3_1 = new JButton("RESERVAR AGORA");
        btnNewButton_1_3_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/site-de-viagens.png")));
        btnNewButton_1_3_1.setForeground(Color.BLACK);
        btnNewButton_1_3_1.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnNewButton_1_3_1.setBackground(new Color(0, 128, 192));
        
        JButton btnNewButton_7_1 = new JButton("");
        btnNewButton_7_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/simbolo-de-informacao.png")));
        btnNewButton_7_1.setBackground(new Color(0, 128, 192));
        
        JButton btnNewButton_1_3_1_1 = new JButton("RESERVAR AGORA");
        btnNewButton_1_3_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/site-de-viagens.png")));
        btnNewButton_1_3_1_1.setForeground(Color.BLACK);
        btnNewButton_1_3_1_1.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnNewButton_1_3_1_1.setBackground(new Color(0, 128, 192));
        
        JButton btnNewButton_7_1_1 = new JButton("");
        btnNewButton_7_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/simbolo-de-informacao.png")));
        btnNewButton_7_1_1.setBackground(new Color(0, 128, 192));
        
        JButton btnNewButton_1_3_1_1_1 = new JButton("RESERVAR AGORA");
        btnNewButton_1_3_1_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/site-de-viagens.png")));
        btnNewButton_1_3_1_1_1.setForeground(Color.BLACK);
        btnNewButton_1_3_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnNewButton_1_3_1_1_1.setBackground(new Color(0, 128, 192));
        
        JButton btnNewButton_7_1_1_1 = new JButton("");
        btnNewButton_7_1_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/simbolo-de-informacao.png")));
        btnNewButton_7_1_1_1.setBackground(new Color(0, 128, 192));
        
        JButton btnNewButton_1_3_1_1_1_1 = new JButton("RESERVAR AGORA");
        btnNewButton_1_3_1_1_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/site-de-viagens.png")));
        btnNewButton_1_3_1_1_1_1.setForeground(Color.BLACK);
        btnNewButton_1_3_1_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnNewButton_1_3_1_1_1_1.setBackground(new Color(0, 128, 192));
        
        JButton btnNewButton_7_1_1_1_1 = new JButton("");
        btnNewButton_7_1_1_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/simbolo-de-informacao.png")));
        btnNewButton_7_1_1_1_1.setBackground(new Color(0, 128, 192));
        
        JButton btnNewButton_1_3_2 = new JButton("RESERVAR AGORA");
        btnNewButton_1_3_2.setIcon(new ImageIcon(teste1.class.getResource("/imagens/site-de-viagens.png")));
        btnNewButton_1_3_2.setForeground(Color.BLACK);
        btnNewButton_1_3_2.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnNewButton_1_3_2.setBackground(new Color(0, 128, 192));
        
        JButton btnNewButton_7_2 = new JButton("");
        btnNewButton_7_2.setIcon(new ImageIcon(teste1.class.getResource("/imagens/simbolo-de-informacao.png")));
        btnNewButton_7_2.setBackground(new Color(0, 128, 192));
        
        JButton btnNewButton_1_3_2_1 = new JButton("RESERVAR AGORA");
        btnNewButton_1_3_2_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/site-de-viagens.png")));
        btnNewButton_1_3_2_1.setForeground(Color.BLACK);
        btnNewButton_1_3_2_1.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnNewButton_1_3_2_1.setBackground(new Color(0, 128, 192));
        
        JButton btnNewButton_7_2_1 = new JButton("");
        btnNewButton_7_2_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/simbolo-de-informacao.png")));
        btnNewButton_7_2_1.setBackground(new Color(0, 128, 192));
        
        JButton btnNewButton_1_3_2_1_1 = new JButton("RESERVAR AGORA");
        btnNewButton_1_3_2_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/site-de-viagens.png")));
        btnNewButton_1_3_2_1_1.setForeground(Color.BLACK);
        btnNewButton_1_3_2_1_1.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnNewButton_1_3_2_1_1.setBackground(new Color(0, 128, 192));
        
        JButton btnNewButton_7_2_1_1 = new JButton("");
        btnNewButton_7_2_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/simbolo-de-informacao.png")));
        btnNewButton_7_2_1_1.setBackground(new Color(0, 128, 192));
        
        JButton btnNewButton_1_3_2_1_1_1 = new JButton("RESERVAR AGORA");
        btnNewButton_1_3_2_1_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/site-de-viagens.png")));
        btnNewButton_1_3_2_1_1_1.setForeground(Color.BLACK);
        btnNewButton_1_3_2_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnNewButton_1_3_2_1_1_1.setBackground(new Color(0, 128, 192));
        
        JButton btnNewButton_7_2_1_1_1 = new JButton("");
        btnNewButton_7_2_1_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/simbolo-de-informacao.png")));
        btnNewButton_7_2_1_1_1.setBackground(new Color(0, 128, 192));
        
        JButton btnNewButton_1_3_2_1_1_1_1 = new JButton("RESERVAR AGORA");
        btnNewButton_1_3_2_1_1_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/site-de-viagens.png")));
        btnNewButton_1_3_2_1_1_1_1.setForeground(Color.BLACK);
        btnNewButton_1_3_2_1_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnNewButton_1_3_2_1_1_1_1.setBackground(new Color(0, 128, 192));
        
        JButton btnNewButton_7_2_1_1_1_1 = new JButton("");
        btnNewButton_7_2_1_1_1_1.setIcon(new ImageIcon(teste1.class.getResource("/imagens/simbolo-de-informacao.png")));
        btnNewButton_7_2_1_1_1_1.setBackground(new Color(0, 128, 192));
        GroupLayout gl_panel_1 = new GroupLayout(panel_1);
        gl_panel_1.setHorizontalGroup(
        	gl_panel_1.createParallelGroup(Alignment.LEADING)
        		.addGroup(gl_panel_1.createSequentialGroup()
        			.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
        				.addComponent(lblNewLabel_1)
        				.addComponent(lblNewLabel_1_1_1_1_2, GroupLayout.PREFERRED_SIZE, 300, GroupLayout.PREFERRED_SIZE)
        				.addGroup(gl_panel_1.createSequentialGroup()
        					.addGap(4)
        					.addComponent(scrollPane_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        					.addPreferredGap(ComponentPlacement.RELATED)
        					.addComponent(btnNewButton_1_3, GroupLayout.PREFERRED_SIZE, 181, GroupLayout.PREFERRED_SIZE)
        					.addGap(18)
        					.addComponent(btnNewButton_7))
        				.addGroup(gl_panel_1.createSequentialGroup()
        					.addContainerGap()
        					.addComponent(btnNewButton_1_3_2, GroupLayout.PREFERRED_SIZE, 181, GroupLayout.PREFERRED_SIZE)
        					.addGap(18)
        					.addComponent(btnNewButton_7_2, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE)))
        			.addGap(70)
        			.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
        				.addComponent(lblNewLabel_1_1, GroupLayout.PREFERRED_SIZE, 300, GroupLayout.PREFERRED_SIZE)
        				.addComponent(lblNewLabel_1_1_1_1_2_1, GroupLayout.PREFERRED_SIZE, 300, GroupLayout.PREFERRED_SIZE)
        				.addGroup(gl_panel_1.createSequentialGroup()
        					.addGap(10)
        					.addComponent(btnNewButton_1_3_1, GroupLayout.PREFERRED_SIZE, 181, GroupLayout.PREFERRED_SIZE)
        					.addGap(18)
        					.addComponent(btnNewButton_7_1, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE))
        				.addGroup(gl_panel_1.createSequentialGroup()
        					.addGap(10)
        					.addComponent(btnNewButton_1_3_2_1, GroupLayout.PREFERRED_SIZE, 181, GroupLayout.PREFERRED_SIZE)
        					.addGap(18)
        					.addComponent(btnNewButton_7_2_1, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE)))
        			.addGap(61)
        			.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
        				.addComponent(lblNewLabel_1_1_1, GroupLayout.PREFERRED_SIZE, 300, GroupLayout.PREFERRED_SIZE)
        				.addComponent(lblNewLabel_1_1_1_1_2_1_1, GroupLayout.PREFERRED_SIZE, 300, GroupLayout.PREFERRED_SIZE)
        				.addGroup(gl_panel_1.createSequentialGroup()
        					.addGap(10)
        					.addComponent(btnNewButton_1_3_1_1, GroupLayout.PREFERRED_SIZE, 181, GroupLayout.PREFERRED_SIZE)
        					.addGap(18)
        					.addComponent(btnNewButton_7_1_1, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE))
        				.addGroup(gl_panel_1.createSequentialGroup()
        					.addGap(10)
        					.addComponent(btnNewButton_1_3_2_1_1, GroupLayout.PREFERRED_SIZE, 181, GroupLayout.PREFERRED_SIZE)
        					.addGap(18)
        					.addComponent(btnNewButton_7_2_1_1, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE)))
        			.addGap(61)
        			.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
        				.addComponent(lblNewLabel_1_1_1_1, GroupLayout.PREFERRED_SIZE, 300, GroupLayout.PREFERRED_SIZE)
        				.addComponent(lblNewLabel_1_1_1_1_2_1_1_1, GroupLayout.PREFERRED_SIZE, 300, GroupLayout.PREFERRED_SIZE)
        				.addGroup(gl_panel_1.createSequentialGroup()
        					.addGap(10)
        					.addComponent(btnNewButton_1_3_1_1_1, GroupLayout.PREFERRED_SIZE, 181, GroupLayout.PREFERRED_SIZE)
        					.addGap(18)
        					.addComponent(btnNewButton_7_1_1_1, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE))
        				.addGroup(gl_panel_1.createSequentialGroup()
        					.addGap(10)
        					.addComponent(btnNewButton_1_3_2_1_1_1, GroupLayout.PREFERRED_SIZE, 181, GroupLayout.PREFERRED_SIZE)
        					.addGap(18)
        					.addComponent(btnNewButton_7_2_1_1_1, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE)))
        			.addGap(70)
        			.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
        				.addGroup(gl_panel_1.createSequentialGroup()
        					.addGap(10)
        					.addComponent(btnNewButton_1_3_2_1_1_1_1, GroupLayout.PREFERRED_SIZE, 181, GroupLayout.PREFERRED_SIZE)
        					.addGap(18)
        					.addComponent(btnNewButton_7_2_1_1_1_1, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE))
        				.addGroup(gl_panel_1.createSequentialGroup()
        					.addGap(10)
        					.addComponent(btnNewButton_1_3_1_1_1_1, GroupLayout.PREFERRED_SIZE, 181, GroupLayout.PREFERRED_SIZE)
        					.addGap(18)
        					.addComponent(btnNewButton_7_1_1_1_1, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE))
        				.addGroup(gl_panel_1.createSequentialGroup()
        					.addComponent(lblNewLabel_1_1_1_1_1, GroupLayout.PREFERRED_SIZE, 300, GroupLayout.PREFERRED_SIZE)
        					.addGap(530)
        					.addComponent(scrollPane_4, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
        				.addComponent(lblNewLabel_1_1_1_1_2_1_1_1_1, GroupLayout.PREFERRED_SIZE, 300, GroupLayout.PREFERRED_SIZE))
        			.addContainerGap(7871, Short.MAX_VALUE))
        );
        gl_panel_1.setVerticalGroup(
        	gl_panel_1.createParallelGroup(Alignment.LEADING)
        		.addGroup(gl_panel_1.createSequentialGroup()
        			.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
        				.addGroup(gl_panel_1.createSequentialGroup()
        					.addGap(106)
        					.addComponent(scrollPane_4, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
        				.addGroup(gl_panel_1.createSequentialGroup()
        					.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
        						.addGroup(gl_panel_1.createSequentialGroup()
        							.addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 562, GroupLayout.PREFERRED_SIZE)
        							.addPreferredGap(ComponentPlacement.RELATED)
        							.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
        								.addComponent(btnNewButton_7)
        								.addComponent(scrollPane_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        								.addComponent(btnNewButton_1_3, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)))
        						.addGroup(gl_panel_1.createSequentialGroup()
        							.addComponent(lblNewLabel_1_1, GroupLayout.PREFERRED_SIZE, 562, GroupLayout.PREFERRED_SIZE)
        							.addPreferredGap(ComponentPlacement.UNRELATED)
        							.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
        								.addComponent(btnNewButton_7_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
        								.addComponent(btnNewButton_1_3_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)))
        						.addGroup(gl_panel_1.createSequentialGroup()
        							.addComponent(lblNewLabel_1_1_1, GroupLayout.PREFERRED_SIZE, 562, GroupLayout.PREFERRED_SIZE)
        							.addPreferredGap(ComponentPlacement.UNRELATED)
        							.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
        								.addComponent(btnNewButton_7_1_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
        								.addComponent(btnNewButton_1_3_1_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)))
        						.addGroup(gl_panel_1.createSequentialGroup()
        							.addComponent(lblNewLabel_1_1_1_1, GroupLayout.PREFERRED_SIZE, 562, GroupLayout.PREFERRED_SIZE)
        							.addPreferredGap(ComponentPlacement.UNRELATED)
        							.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
        								.addComponent(btnNewButton_7_1_1_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
        								.addComponent(btnNewButton_1_3_1_1_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)))
        						.addGroup(gl_panel_1.createSequentialGroup()
        							.addComponent(lblNewLabel_1_1_1_1_1, GroupLayout.PREFERRED_SIZE, 562, GroupLayout.PREFERRED_SIZE)
        							.addPreferredGap(ComponentPlacement.RELATED)
        							.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
        								.addComponent(btnNewButton_7_1_1_1_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
        								.addComponent(btnNewButton_1_3_1_1_1_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE))))
        					.addGap(104)
        					.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
        						.addComponent(lblNewLabel_1_1_1_1_2_1_1_1_1, GroupLayout.PREFERRED_SIZE, 562, GroupLayout.PREFERRED_SIZE)
        						.addComponent(lblNewLabel_1_1_1_1_2_1_1_1, GroupLayout.PREFERRED_SIZE, 562, GroupLayout.PREFERRED_SIZE)
        						.addComponent(lblNewLabel_1_1_1_1_2_1_1, GroupLayout.PREFERRED_SIZE, 562, GroupLayout.PREFERRED_SIZE)
        						.addComponent(lblNewLabel_1_1_1_1_2_1, GroupLayout.PREFERRED_SIZE, 562, GroupLayout.PREFERRED_SIZE)
        						.addComponent(lblNewLabel_1_1_1_1_2, GroupLayout.PREFERRED_SIZE, 562, GroupLayout.PREFERRED_SIZE))))
        			.addPreferredGap(ComponentPlacement.RELATED)
        			.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
        				.addComponent(btnNewButton_1_3_2, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
        				.addComponent(btnNewButton_7_2, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
        				.addComponent(btnNewButton_1_3_2_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
        				.addComponent(btnNewButton_7_2_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
        				.addComponent(btnNewButton_1_3_2_1_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
        				.addComponent(btnNewButton_7_2_1_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
        				.addComponent(btnNewButton_1_3_2_1_1_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
        				.addComponent(btnNewButton_7_2_1_1_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
        				.addComponent(btnNewButton_1_3_2_1_1_1_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
        				.addComponent(btnNewButton_7_2_1_1_1_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE))
        			.addContainerGap(543, Short.MAX_VALUE))
        );
        panel_1.setLayout(gl_panel_1);
        
        JMenuBar menuBar_1 = new JMenuBar();
        frame.setJMenuBar(menuBar_1);
        
        JMenuItem mntmNewMenuItem_5 = new JMenuItem("LOGIN/CADASTRO");
        mntmNewMenuItem_5.setBackground(new Color(255, 255, 255));
        mntmNewMenuItem_5.setFont(new Font("Segoe UI", Font.BOLD, 12));
        mntmNewMenuItem_5.setHorizontalAlignment(SwingConstants.LEFT);
        mntmNewMenuItem_5.setIcon(new ImageIcon(teste1.class.getResource("/imagens/login-de-usuario.png")));
        menuBar_1.add(mntmNewMenuItem_5);
    }
	private static void addPopup(Component component, final JPopupMenu popup) {
		component.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}
			public void mouseReleased(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}
			private void showMenu(MouseEvent e) {
				popup.show(e.getComponent(), e.getX(), e.getY());
			}
		});
	}
}
